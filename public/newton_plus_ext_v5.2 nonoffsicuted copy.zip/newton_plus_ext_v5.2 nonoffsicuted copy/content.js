const a0_0x386f54 = a0_0x3f8f; function a0_0x3f8f(_0x1c5790, _0x310de9) { const _0x522f88 = a0_0x522f(); return a0_0x3f8f = function (_0x3f8f6d, _0x13931e) { _0x3f8f6d = _0x3f8f6d - 0xc5; let _0x4681c1 = _0x522f88[_0x3f8f6d]; return _0x4681c1; }, a0_0x3f8f(_0x1c5790, _0x310de9); } (function (_0x1bab4b, _0x3c317d) { const _0x2ec3b6 = a0_0x3f8f, _0x4a6d2d = _0x1bab4b(); while (!![]) { try { const _0x5e917f = -parseInt(_0x2ec3b6(0xd6)) / 0x1 + parseInt(_0x2ec3b6(0xdf)) / 0x2 * (-parseInt(_0x2ec3b6(0xd2)) / 0x3) + -parseInt(_0x2ec3b6(0xc6)) / 0x4 * (-parseInt(_0x2ec3b6(0xd1)) / 0x5) + -parseInt(_0x2ec3b6(0xd5)) / 0x6 + -parseInt(_0x2ec3b6(0xd4)) / 0x7 + -parseInt(_0x2ec3b6(0xc7)) / 0x8 + parseInt(_0x2ec3b6(0xd7)) / 0x9; if (_0x5e917f === _0x3c317d) break; else _0x4a6d2d['push'](_0x4a6d2d['shift']()); } catch (_0x14c393) { _0x4a6d2d['push'](_0x4a6d2d['shift']()); } } }(a0_0x522f, 0xd4bf8)); const a0_0x42aa2d = a0_0x26b3; (function (_0x3ca939, _0x3eedfd) { const _0x2e23e2 = a0_0x3f8f, _0x158e48 = a0_0x26b3, _0x18469b = _0x3ca939(); while (!![]) { try { const _0x2a487c = parseInt(_0x158e48(0x166)) / 0x1 * (-parseInt(_0x158e48(0x168)) / 0x2) + parseInt(_0x158e48(0x169)) / 0x3 * (-parseInt(_0x158e48(0x162)) / 0x4) + -parseInt(_0x158e48(0x160)) / 0x5 + -parseInt(_0x158e48(0x16a)) / 0x6 * (parseInt(_0x158e48(0x16d)) / 0x7) + parseInt(_0x158e48(0x16c)) / 0x8 * (-parseInt(_0x158e48(0x15f)) / 0x9) + -parseInt(_0x158e48(0x161)) / 0xa * (parseInt(_0x158e48(0x15c)) / 0xb) + -parseInt(_0x158e48(0x164)) / 0xc * (-parseInt(_0x158e48(0x15d)) / 0xd); if (_0x2a487c === _0x3eedfd) break; else _0x18469b[_0x2e23e2(0xcf)](_0x18469b[_0x2e23e2(0xcd)]()); } catch (_0x11bc21) { _0x18469b[_0x2e23e2(0xcf)](_0x18469b[_0x2e23e2(0xcd)]()); } } }(a0_0x1b2c, 0x6ee9b)); function a0_0x522f() { const _0x45131b = ['local', '12rTTvvu', '2284570PeExnF', '54543073xpMwlS', '103046pzpHHY', 'set', '4mXXcAK', '4385800jZVFyJ', '33SLCBUF', '241854zFlcLE', '7kNrjfc', '556rCEFem', 'storage', 'shift', 'auth-token', 'push', 'log', '6991045xqYBEg', '27MYqUZO', '8fHMiXu', '3222940xGQVjd', '1016826bWWINe', '1320395pBjIjE', '21918825AYmBeP', '3CTgwlN', '16374fiAFxV', '402592PBDElS']; a0_0x522f = function () { return _0x45131b; }; return a0_0x522f(); } function a0_0x26b3(_0x20f22d, _0x4039b4) { const _0x4c3f40 = a0_0x1b2c(); return a0_0x26b3 = function (_0x86f73d, _0x4b6792) { _0x86f73d = _0x86f73d - 0x15c; let _0x11d362 = _0x4c3f40[_0x86f73d]; return _0x11d362; }, a0_0x26b3(_0x20f22d, _0x4039b4); } function a0_0x1b2c() { const _0x3232b4 = a0_0x3f8f, _0x26defd = ['Auth\\x20token\\x20found:', _0x3232b4(0xda), _0x3232b4(0xd9), _0x3232b4(0xc9), _0x3232b4(0xce), _0x3232b4(0xd3), _0x3232b4(0xca), 'getItem', _0x3232b4(0xc8), _0x3232b4(0xde), _0x3232b4(0xd0), '7367364CceUAA', '4172480cWDKLH', _0x3232b4(0xdd), _0x3232b4(0xcb), _0x3232b4(0xdb), _0x3232b4(0xdc), _0x3232b4(0xcc), _0x3232b4(0xd8)]; return a0_0x1b2c = function () { return _0x26defd; }, a0_0x1b2c(); } const token = localStorage[a0_0x42aa2d(0x16e)](a0_0x42aa2d(0x16b)); console[a0_0x42aa2d(0x15e)](a0_0x42aa2d(0x167), !!token), token && chrome[a0_0x42aa2d(0x165)][a0_0x42aa2d(0x163)][a0_0x386f54(0xc5)]({ 'authToken': token });

// ── Newton Plus: Premium Website Dark Mode ───────────────────────────────────

const NEWTON_DARK_STYLE_ID = 'newton-plus-dark-mode';

const NEWTON_DARK_CSS = `

  /*
   * Professional Dark Mode — Filter Invert Technique
   * Works like Dark Reader: inverts all colors then hue-rotates back so
   * blues stay blue, reds stay red, etc. Images are double-inverted to
   * restore natural colors. Result: clean, uniform dark mode on any page.
   */

  html {
    filter: invert(92%) hue-rotate(180deg) !important;
    background: #fff !important;
  }

  /*
   * Restore elements that should NOT be inverted:
   * images, videos, iframes, canvases, and colored UI components.
   * Double-inverting = back to original colors.
   */
  img,
  video,
  iframe,
  canvas,
  picture,
  svg image,
  [class*="avatar"] img,
  [class*="Avatar"] img,
  [class*="thumbnail"],
  [class*="Thumbnail"],
  [class*="preview-img"],
  [class*="cover-img"],
  [class*="banner-img"] {
    filter: invert(100%) hue-rotate(180deg) !important;
  }

  /* Restore emoji & icon images that use inlined SVG or img */
  [class*="emoji"],
  [class*="Emoji"] {
    filter: invert(100%) hue-rotate(180deg) !important;
  }

  /* Boost contrast a little for readability */
  body * {
    --filter-dm-brightness: 1;
  }

  /* Smooth scrollbar for dark bg */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  ::-webkit-scrollbar-track {
    background: #1a1d27;
  }
  ::-webkit-scrollbar-thumb {
    background-color: #4b5563;
    border-radius: 4px;
  }
  ::-webkit-scrollbar-thumb:hover {
    background-color: #9ca3af;
  }
`;

/**
 * Injects or removes the Newton dark mode <style> tag.
 * @param {boolean} enable
 */
function applyNewtonDarkMode(enable) {
  const existing = document.getElementById(NEWTON_DARK_STYLE_ID);
  if (enable) {
    if (!existing) {
      const style = document.createElement('style');
      style.id = NEWTON_DARK_STYLE_ID;
      style.textContent = NEWTON_DARK_CSS;
      // Inject into <head> with highest priority
      (document.head || document.documentElement).appendChild(style);
    }
  } else {
    if (existing) existing.remove();
  }
}

/**
 * Returns true if the current URL is a playground or lecture page that should
 * be excluded from dark mode.
 */
function _isExcludedUrl() {
  const path = window.location.pathname;
  return /\/playground\//i.test(path) || /^\/lecture\//i.test(path);
}

/**
 * Re-evaluates whether dark mode should be active based on
 * stored preference AND current URL. Called on every route change.
 */
function _syncDarkMode(websiteDarkModeEnabled) {
  if (websiteDarkModeEnabled && !_isExcludedUrl()) {
    applyNewtonDarkMode(true);
  } else {
    applyNewtonDarkMode(false);
  }
}

// Cache the enabled state so route-change handler can use it without
// re-querying storage every time.
let _websiteDarkEnabled = false;

// Initial load: read preference and apply
chrome.storage.local.get(['websiteDarkMode'], function (result) {
  _websiteDarkEnabled = result.websiteDarkMode === true;
  _syncDarkMode(_websiteDarkEnabled);
});

// ── SPA navigation watcher ───────────────────────────────────────────────────
// React updates document.title on every route change. Watching <head>/<title>
// via MutationObserver is the most reliable way to detect SPA navigation
// without depending on intercepting history before React's router sets up.

let _lastHref = window.location.href;

function _onRouteChange() {
  const currentHref = window.location.href;
  if (currentHref !== _lastHref) {
    _lastHref = currentHref;
    // Small delay so the new route's DOM settles
    setTimeout(() => _syncDarkMode(_websiteDarkEnabled), 80);
  }
}

// Watch <head> — React updates <title> on every navigation
const _routeObserver = new MutationObserver(_onRouteChange);
_routeObserver.observe(document.documentElement, {
  subtree: true,
  childList: true,
  characterData: true
});

// Also cover browser back/forward
window.addEventListener('popstate', () => {
  setTimeout(() => _syncDarkMode(_websiteDarkEnabled), 80);
});

// ── Listen for live toggle messages from the popup ──────────────────────────
chrome.runtime.onMessage.addListener(function (message) {
  if (message && message.action === 'setWebsiteDarkMode') {
    _websiteDarkEnabled = message.enabled;
    _syncDarkMode(_websiteDarkEnabled);
  }
});

// ── End Newton Plus: Premium Website Dark Mode ───────────────────────────────