// Reset manual adjustments every time popup opens (Chrome extension unload is unreliable)
localStorage.removeItem("manual-adjusted");
localStorage.removeItem("totalAdjustments");
window._cachedSubjectData = {};
window._npEmail = null; // Stores user email for personal notification fetching

// Global API Configuration
// const NEWTON_API_BASE = "http://localhost:3000";
const NEWTON_API_BASE = "https://newtonplusdata.vercel.app";

// Safety: Prevent crashes from phantom function calls
window.loadGistsPanel = () => console.warn("Newton+: loadGistsPanel invoked but not active.");

function a0_0x5a59(_0x14cd9a, _0x5eebf7) {
    const _0x17ff8e = a0_0x17ff();
    return (
        (a0_0x5a59 = function (_0x5a5921, _0x53ca08) {
            _0x5a5921 = _0x5a5921 - 0x1de;
            let _0x472877 = _0x17ff8e[_0x5a5921];
            return _0x472877;
        }),
        a0_0x5a59(_0x14cd9a, _0x5eebf7)
    );
}
const a0_0x372412 = a0_0x5a59;
((function (_0x4ea5ce, _0x4190e3) {
    const _0x5552a8 = a0_0x5a59,
        _0xa6ff46 = _0x4ea5ce();
    while (!![]) {
        try {
            const _0x1ecf27 =
                parseInt(_0x5552a8(0x249)) / 0x1 +
                (parseInt(_0x5552a8(0x223)) / 0x2) *
                (parseInt(_0x5552a8(0x1ef)) / 0x3) +
                -parseInt(_0x5552a8(0x2c3)) / 0x4 +
                parseInt(_0x5552a8(0x226)) / 0x5 +
                parseInt(_0x5552a8(0x22a)) / 0x6 +
                parseInt(_0x5552a8(0x284)) / 0x7 +
                (-parseInt(_0x5552a8(0x259)) / 0x8) *
                (-parseInt(_0x5552a8(0x29b)) / 0x9);
            if (_0x1ecf27 === _0x4190e3) break;
            else _0xa6ff46["push"](_0xa6ff46["shift"]());
        } catch (_0x3bfa2f) {
            _0xa6ff46["push"](_0xa6ff46["shift"]());
        }
    }
})(a0_0x17ff, 0x5c696),
    window[a0_0x372412(0x262)](a0_0x372412(0x208), () => {
        const _0x298256 = a0_0x372412;
        (localStorage["removeItem"](_0x298256(0x2d7)),
            localStorage[_0x298256(0x28c)](_0x298256(0x26a)));
    }));
function a0_0x17ff() {
    const _0x445725 = [
        "manual-adjusted",
        "settings-view",
        "json",
        "<div\x20class=\x27user-welcome\x27><span\x20class=\x22welcome-highlight\x22>Welcome</span>\x20<span\x20class=\x22name-highlight\x22>!</span></div>",
        "replace",
        "learning_unit_courses",
        "Error\x20loading\x20config:",
        "REMOVED_TOKEN",
        "getItem",
        "<div\x20class=\x27group\x27>\x0a\x20\x20\x20\x20\x20\x20<h2>",
        "style=\x22display:\x20none;\x22",
        "credit",
        "<p\x20style=\x22color:\x20#666;\x20font-style:\x20italic;\x22>No\x20subjects\x20found.\x20Make\x20sure\x20you\x27re\x20on\x20a\x20course\x20page.</p>",
        "Update\x20Group",
        "createElement",
        "317545QCYBdZ",
        "display",
        "Could\x20not\x20fetch\x20notifications\x20from\x20gist",
        "premium",
        "Attendance\x20calculations\x20toggle\x20changed\x20to:",
        "<p\x20class=\x22limit-message\x22>⭐\x20Free\x20users\x20can\x20create\x20up\x20to\x20",
        "toggle",
        "YWxsdXNlcnM=",
        "pointer",
        "401: Please Contact Support.",
        "\x20while\x20maintaining\x20≥75%\x20attendance</td></tr>",
        ".dots-menu[data-group=\x22",
        "REMOVED_TOKEN",
        "Authorization",
        "manualOverrideEnabled",
        "User",
        "214664TTkwgQ",
        "selected-tag",
        "currentConfig",
        "short_display_name",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22adjustment-buttons\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22adjust-btn\x20attended-plus\x22\x20data-subject-hash=\x22",
        "data-feature",
        ".dots-menu-btn",
        "<span\x20class=\x22premium-badge\x22>PREMIUM</span>\x20Attendance\x20calculations\x20enabled.\x20Enable\x20manual\x20override\x20in\x20Settings\x20for\x20adjustment\x20buttons.",
        "<span\x20class=\x22premium-required\x22>⭐\x20Premium\x20required</span>",
        "addEventListener",
        "textContent",
        ".adjust-btn",
        "data-group",
        "<tr\x20class=\x27attend-info\x27><td\x20colspan=\x272\x27>Attend\x20",
        "flat",
        "forEach",
        "block",
        "totalAdjustments",
        "local",
        "getAttribute",
        "Sending\x20to\x20API:",
        "\x22\x20style=\x22display:none;\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22menu-delete-btn\x22\x20data-group=\x22",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20</div>",
        "notification",
        "setItem",
        "${hash}",
        "hash",
        "attendanceGroups",
        "click",
        "querySelectorAll",
        "join",
        "length",
        "cloneNode",
        "floor",
        '<div style=\"background:#fee2e2;color:#b91c1c;padding:10px;border-radius:6px;border:1px solid #fca5a5;margin:5px 0;\">Please refresh the course page</div>',
        "data-hash",
        "\x22\x20data-hash=\x22",
        "data-type",
        "Error\x20fetching\x20attendance\x20for",
        "Please\x20select\x20at\x20least\x20one\x20subject",
        "last_name",
        "notification-bar",
        "Auth\x20token\x20in\x20popup:",
        "1241023yXMnAb",
        "toFixed",
        "No\x20user\x20email\x20found",
        "admin_unit_courses",
        "trim",
        "manual-override-toggle",
        "preventDefault",
        ".info-icon",
        "removeItem",
        "attendance",
        "change",
        '<div style=\"background:#fee2e2;color:#b91c1c;padding:10px;border-radius:6px;border:1px solid #fca5a5;margin:5px 0;\">Please refresh the course page</div>',
        "querySelector",
        "message",
        "subject-search",
        "username",
        "map",
        "allowed_subject_group",
        "Failed\x20to\x20push\x20to\x20API:",
        "<tr><td>",
        "settings",
        "</span>",
        "parse",
        "54ZXUpVB",
        "<span\x20class=\x22subject-tag\x22>",
        "Fetching\x20attendance\x20for:",
        "settings-tab",
        "appendChild",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subject-chip\x20",
        "attendance-calculations",
        "ceil",
        "then",
        "Admin\x20unit\x20not\x20found",
        "div",
        "none",
        "<a\x20href=\x22$1\x22\x20target=\x22_blank\x22\x20rel=\x22noopener\x20noreferrer\x22>$1</a>",
        "tabs",
        "userMeUrl",
        "reason",
        "checked",
        '<div style=\"text-align:center;padding:15px;background:#fff7ed;border:1px solid #ffedd5;border-radius:8px;color:#9a3412;margin:10px 0;font-family:system-ui;\"><h3 style=\"margin:0 0 5px 0;font-size:15px;\">Something went wrong !</h3><div style=\"background:#fff;padding:8px;border-radius:6px;margin:10px 0;border:1px solid #fed7aa;font-size:12px;\"><strong>An Update May Be Available</strong><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\" style=\"color:#ea580c;text-decoration:none;font-weight:bold;\">Visit newton-brown.vercel.app</a></div></div>',
        "Could\x20not\x20load\x20token\x20for\x20notifications:",
        ".subject-chip",
        "%\x20(",
        ".dots-menu",
        "REMOVED_TOKEN",
        "Not\x20on\x20a\x20valid\x20course\x20page",
        "Please\x20select\x20at\x20least\x20one\x20subject\x20for\x20the\x20group",
        "stopPropagation",
        "User\x20data\x20saved:",
        "parentNode",
        "className",
        "Service\x20temporarily\x20unavailable",
        "attendance-view",
        "match",
        "toLowerCase",
        '<div style=\"text-align:center;padding:15px;background:#fff7ed;border:1px solid #ffedd5;border-radius:8px;color:#9a3412;margin:10px 0;font-family:system-ui;\"><h3 style=\"margin:0 0 5px 0;font-size:15px;\">Something went wrong !</h3><div style=\"background:#fff;padding:8px;border-radius:6px;margin:10px 0;border:1px solid #fed7aa;font-size:12px;\"><strong>An Update May Be Available</strong><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\" style=\"color:#ea580c;text-decoration:none;font-weight:bold;\">Visit newton-brown.vercel.app</a></div></div>',
        "\x0a\x20\x20\x20\x20<div\x20class=\x22settings-section\x22>\x0a\x20\x20\x20\x20\x20\x20<h3>Premium\x20Features</h3>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22premium-feature-item\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22feature-name\x22>Manual\x20Override</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22info-icon\x22\x20data-feature=\x22manual-override\x22\x20title=\x22Click\x20for\x20more\x20info\x22>ℹ️</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-description\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Manually\x20adjust\x20attended/total\x20classes\x20when\x20portal\x20is\x20slow\x20to\x20update\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-toggle\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20class=\x22toggle-switch\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22checkbox\x22\x20id=\x22manual-override-toggle\x22\x20",
        '<div class="newton-notif notif-normal"><div class="notif-header"><span class="notif-badge">\\uD83D\\uDCE2 System</span><span class="notif-title"></span></div><div class="notification-content">',
        "attendance-tab",
        "Manual\x20Override\x20Feature:\x0a\x0a•\x20Green\x20+\x20button:\x20Add\x20to\x20attended\x20classes\x0a•\x20Red\x20+\x20button:\x20Add\x20to\x20total\x20classes\x0a•\x20Yellow\x20highlight:\x20Subject\x20has\x20manual\x20adjustments\x0a•\x20Adjustments\x20reset\x20when\x20extension\x20closes\x0a•\x20Helps\x20when\x20portal\x20is\x20slow\x20to\x20update\x20attendance",
        "Please\x20enter\x20a\x20group\x20name",
        "application/json",
        "2847004UYAwed",
        "delete",
        "content",
        "getElementById",
        "<div\x20class=\x27loading\x27><div\x20class=\x27spinner\x27></div><p>Loading\x20settings...</p></div>",
        "children_courses",
        "available-list",
        "apiDataUrl",
        "Manual\x20override\x20toggle\x20changed\x20to:",
        "coursesUrl",
        "has",
        "query",
        "Error\x20loading\x20access\x20control:",
        "\x22\x20aria-label=\x22More\x20options\x22>&#8942;</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22dots-menu\x22\x20data-group=\x22",
        "isPremium",
        "input",
        "</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22group-actions\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22dots-menu-btn\x22\x20data-group=\x22",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>",
        "span",
        "filter",
        "ghostClasses",
        "first_name",
        "isPremiumUser",
        "\x20to\x20reach\x2075%\x20attendance</td></tr>",
        "value",
        "Config\x20file\x20not\x20found\x20in\x20gist",
        ">\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22toggle-slider\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
        "GitHub\x20API\x20rate\x20limit\x20exceeded.\x20Please\x20check\x20your\x20token\x20configuration.",
        "from",
        "style",
        "<tr\x20class=\x27total-row\x27>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<td><strong>Total</strong></td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<td><strong>",
        "group-name",
        "reload",
        "authToken",
        "get",
        "Unable\x20to\x20load\x20config\x20from\x20gist.",
        "cursor",
        "add",
        "some",
        "grouped",
        "6YUsFod",
        "contains",
        "slice",
        "log",
        "</table></div>",
        "setAttribute",
        "\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22settings-section\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<h3>Create\x20New\x20Group</h3>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22add-group-form\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22form-group\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22group-name\x22>Group\x20Name:</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22text\x22\x20id=\x22group-name\x22\x20placeholder=\x22Enter\x20group\x20name\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22form-group\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22selected-subjects-preview\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h4>Selected\x20Subjects:</h4>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22selected-subjects-tags\x22\x20class=\x22selected-tags\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Selected\x20subjects\x20will\x20appear\x20here\x20as\x20tags\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22available-subjects-container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h4>Available\x20Subjects:</h4>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22available-list\x22\x20class=\x22available-grid\x22>",
        "title",
        '<div style=\"text-align:center;padding:15px;background:#fff7ed;border:1px solid #ffedd5;border-radius:8px;color:#9a3412;margin:10px 0;font-family:system-ui;\"><h3 style=\"margin:0 0 5px 0;font-size:15px;\">Something went wrong !</h3><div style=\"background:#fff;padding:8px;border-radius:6px;margin:10px 0;border:1px solid #fed7aa;font-size:12px;\"><strong>An Update May Be Available</strong><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\" style=\"color:#ea580c;text-decoration:none;font-weight:bold;\">Visit newton-brown.vercel.app</a></div></div>',
        "storage",
        "entries",
        "true",
        "urlTemplate",
        "url",
        "active",
        "github_token",
        "files",
        "status",
        "Course\x20not\x20found",
        "access.json",
        "\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td>",
        "classList",
        "attendanceCalculationsEnabled",
        "total_lectures",
        "<p>Create\x20groups\x20of\x20subjects\x20to\x20view\x20combined\x20attendance\x20statistics.\x20Groups\x20are\x20saved\x20locally\x20in\x20your\x20browser.</p>",
        "load",
        "replaceChild",
        "error",
        "includes",
        "\x22>Delete</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subjects-list\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
        "manual-override",
        "\x20more\x20class",
        "Failed\x20to\x20fetch\x20courses:\x20",
        "allowedSubjectGroups",
        "target",
        "<div\x20class=\x27user-welcome\x27><span\x20class=\x22welcome-highlight\x22>Welcome,</span>\x20<span\x20class=\x22name-highlight\x22>",
        "create-group-btn",
        "https://api.github.com/gists/",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-success\x22\x20id=\x22create-group-btn\x22\x20",
        "User\x20API\x20response\x20status:",
        "</td></tr>",
        "</td>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<td\x20style=\x22position:\x20relative;\x22>",
        "user-info",
        "max",
        ")</td></tr>",
        ".selected-tag",
        "values",
        '<div style=\"text-align:center;padding:15px;background:#fff7ed;border:1px solid #ffedd5;border-radius:8px;color:#9a3412;margin:10px 0;font-family:system-ui;\"><h3 style=\"margin:0 0 5px 0;font-size:15px;\">Something went wrong !</h3><div style=\"background:#fff;padding:8px;border-radius:6px;margin:10px 0;border:1px solid #fed7aa;font-size:12px;\"><strong>An Update May Be Available</strong><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\" style=\"color:#ea580c;text-decoration:none;font-weight:bold;\">Visit newton-brown.vercel.app</a></div></div>',
        "stringify",
        "total_lectures_attended",
        "disabled",
        "config.json",
        "217110QCjEzg",
        "\x20groups\x20allowed\x20for\x20free\x20users.</p>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<p>⭐\x20Upgrade\x20to\x20premium\x20for\x20unlimited\x20subject\x20groups!</p>\x0a\x20\x20\x20\x20\x20\x20</div>",
        "URL:",
        "781525LNKSHt",
        "removeEventListener",
        "innerHTML",
        "API\x20response\x20status:",
        "366132gvKUoO",
        "size",
        "Attendance\x20Calculations\x20Feature:\x0a\x0a•\x20Shows\x20how\x20many\x20classes\x20you\x20can\x20bunk\x20while\x20maintaining\x2075%\x20attendance\x0a•\x20Shows\x20how\x20many\x20more\x20classes\x20you\x20need\x20to\x20attend\x20to\x20reach\x2075%\x0a•\x20Calculations\x20include\x20your\x20manual\x20adjustments\x0a•\x20Helps\x20you\x20plan\x20your\x20attendance\x20strategy",
        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22premium-feature-item\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22feature-name\x22>Attendance\x20Calculations</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22info-icon\x22\x20data-feature=\x22attendance-calculations\x22\x20title=\x22Click\x20for\x20more\x20info\x22>ℹ️</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-description\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Show\x20bunkable\x20classes\x20and\x20attendance\x20requirements\x20in\x20attendance\x20view\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22feature-toggle\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20class=\x22toggle-switch\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22checkbox\x22\x20id=\x22attendance-calculations-toggle\x22\x20",
        "</div>",
        "find",
        "subject-chip",
        "\x22\x20data-type=\x22total\x22\x20title=\x22Add\x20total\x20class\x22>+</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>",
        "Bearer\x20",
        "token\x20",
        "warn",
        "REMOVED_TOKEN",
        "attendance-calculations-toggle",
        "total",
        "marginLeft",
        "allowed",
    ];
    a0_0x17ff = function () {
        return _0x445725;
    };
    return a0_0x17ff();
}
function switchTab(_0x46046e) {
    const _0xea1690 = a0_0x372412,
        _0x523e34 = document[_0xea1690(0x2c6)]("attendance-tab"),
        _0x533d82 = document[_0xea1690(0x2c6)](_0xea1690(0x29e)),
        _0x31d3ba = document[_0xea1690(0x2c6)]("attendance-view"),
        _0x42683d = document[_0xea1690(0x2c6)](_0xea1690(0x23b));
    (_0x523e34 &&
        _0x523e34["classList"][_0xea1690(0x24f)](
            "active",
            _0x46046e === _0xea1690(0x28d),
        ),
        _0x533d82 &&
        _0x533d82[_0xea1690(0x204)][_0xea1690(0x24f)](
            _0xea1690(0x1fd),
            _0x46046e === "settings",
        ),
        _0x31d3ba &&
        _0x31d3ba["classList"]["toggle"](
            "active",
            _0x46046e === _0xea1690(0x28d),
        ),
        _0x42683d &&
        _0x42683d["classList"][_0xea1690(0x24f)](
            "active",
            _0x46046e === "settings",
        ));
    if (_0x46046e === "settings") {
        const s = document.getElementById("settings");
        if (!s || !s.querySelector("#popup-dark-mode-toggle")) loadSettings();
    } else if (_0x46046e === _0xea1690(0x28d)) {
        if (window._attendanceDirty) {
            window._attendanceDirty = false;
            if (window.currentConfig) fetchAttendance(window.currentConfig);
        }
    }
}
const attendanceTab = document[a0_0x372412(0x2c6)](a0_0x372412(0x2bf)),
    settingsTab = document["getElementById"](a0_0x372412(0x29e));
attendanceTab &&
    attendanceTab[a0_0x372412(0x262)](a0_0x372412(0x275), () =>
        switchTab(a0_0x372412(0x28d)),
    );
settingsTab &&
    settingsTab["addEventListener"](a0_0x372412(0x275), () =>
        switchTab(a0_0x372412(0x298)),
    );

async function getDecodedConfig() {
    let attempts = 0;
    while (!window.currentConfig && attempts < 50) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
    }
    return window.currentConfig;
}

async function loadConfig() {
    // Legacy support
    return window.currentConfig;
}

async function loadAccessControl() {
    return { allowed: true, isPremium: window.isPremiumUser };
}

async function initializeNewtonPlus() {
    const errorContainer =
        document.querySelector(".attendance-view") || document.body;
    try {
        const { authToken } = await chrome.storage.local.get("authToken");
        if (!authToken) {
            if (errorContainer)
                errorContainer.innerHTML = getErrorHtml(
                    "Please refresh the page and try again.",
                );
            return;
        }

        const userMeUrl = "https://my.newtonschool.co/api/v1/user/me/";
        const userRes = await fetch(userMeUrl, {
            headers: {
                Authorization: "Bearer " + authToken,
                Accept: "application/json",
            },
        });

        if (!userRes.ok) {
            if (errorContainer)
                errorContainer.innerHTML = getErrorHtml(
                    "Failed to fetch user info from Newton.",
                );
            return;
        }

        const userData = await userRes.json();
        const userEmail = userData.email || userData.username || "";
        if (!userEmail) {
            if (errorContainer)
                errorContainer.innerHTML = getErrorHtml("No user email found.");
            return;
        }
        window._npEmail = userEmail;
        // Store user data globally NOW so it is available when instant custom blocks render
        window._npUserData = userData;
        window._npVersion = (typeof chrome !== 'undefined' && chrome.runtime)
            ? chrome.runtime.getManifest().version : "5.0";

        const url =
            NEWTON_API_BASE + "/api/extension/sync?email=" +
            encodeURIComponent(userEmail);
        const response = await fetch(url, { cache: "no-store" });

        if (!response.ok) {
            throw new Error(
                `Server returned ${response.status}. Please ensure your API is deployed.`,
            );
        }

        const config = await response.json();

        // Handle merged notifications from sync response
        if (config.notifications) {
            window._npNotifications = config.notifications;
            fetchPersonalNotifications(userEmail, config.notifications);
        }

        if (config.access === "BLOCKED") {
            const attendanceView = document.getElementById("attendance-view");
            const userInfo = document.getElementById("user-info");
            const settingsView = document.getElementById("settings-view");
            const tabContainer = document.querySelector(".tab-container");
            const bellContainer = document.querySelector(".notif-bell-container");

            // Stop all fetching and hide everything
            if (userInfo) userInfo.innerHTML = "";
            if (tabContainer) tabContainer.style.display = "none";
            if (settingsView) settingsView.style.display = "none";
            if (bellContainer) bellContainer.style.display = "none";

            if (attendanceView) {
                attendanceView.innerHTML = `
          <div class="api-error-takeover">
            <div class="api-error-icon-circle">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                <line x1="9" y1="9" x2="15" y2="15"></line>
                <line x1="15" y1="9" x2="9" y2="15"></line>
              </svg>
            </div>
            <div class="limit-title">Connection Lost</div>
            <p class="limit-justification">
              We're unable to reach the Newton Plus servers. This could be due to a network interruption or temporary maintenance. Error: restricted
            </p>
            <div class="api-error-status-pill">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="2" y1="12" x2="22" y2="12"></line>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
              </svg>
              <span class="api-error-status-text">STATUS: OFFLINE</span>
            </div>
            
            <div style="margin-top: auto; padding: 20px; border-top: 1px solid rgba(226, 232, 240, 0.1); width: 100%;">
              <p style="font-size: 13px; color: #64748b; margin: 0;">For support, visit our website :</p>
              <a href="https://newton-brown.vercel.app/" target="_blank" style="color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 13px; display: block; margin-top: 8px;">newton-brown.vercel.app</a>
            </div>
          </div>
        `;
                attendanceView.style.display = "block";
                attendanceView.classList.add("active");
            }
            return;
        }

        if (config.access === "LIMIT_REACHED") {
            const attendanceView = document.getElementById("attendance-view");
            const userInfo = document.getElementById("user-info");
            const settingsView = document.getElementById("settings-view");
            const tabContainer = document.querySelector(".tab-container");
            const bellContainer = document.querySelector(".notif-bell-container");

            // Stop all fetching and hide everything
            if (userInfo) userInfo.innerHTML = "";
            if (tabContainer) tabContainer.style.display = "none";
            if (settingsView) settingsView.style.display = "none";
            if (bellContainer) bellContainer.style.display = "none";

            if (attendanceView) {
                // Calculate time until midnight reset
                const now = new Date();
                const midnight = new Date();
                midnight.setHours(24, 0, 0, 0);
                const diffMs = midnight - now;
                const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                const resetStr = `RESETS IN ${diffHrs}H ${diffMins}M`;

                // We replace the ENTIRE attendanceView to remove the feedback footer
                attendanceView.innerHTML = `
          <div class="limit-takeover">
            <div class="limit-icon-circle">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
            </div>
            <div class="limit-title">Daily Limit Reached</div>
            <p class="limit-justification">
              To maintain peak performance and fair access for the community, Newton Plus uses a daily fair-use limit. This prevents excessive server load and keeps the extension fast for everyone.
            </p>
            <div class="limit-status-pill" style="margin-bottom: 30px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              <span class="limit-reset-time">${resetStr}</span>
            </div>
            
            <div style="margin-top: auto; padding: 20px; border-top: 1px solid rgba(226, 232, 240, 0.1); width: 100%;">
              <p style="font-size: 13px; color: #64748b; margin: 0;">For support, visit our website and fill the form:</p>
              <a href="https://newton-brown.vercel.app/" target="_blank" style="color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 13px; display: block; margin-top: 8px;">newton-brown.vercel.app</a>
            </div>
          </div>
        `;
                attendanceView.style.display = "block";
                attendanceView.classList.add("active");
            }
            return;
        }

        const sys = config.system;
        const feat = config.features;

        // Granular Backend Rules now rule supreme. Bypass native hierarchy locks.
        window.isPremiumUser = true;
        window.allowedSubjectGroups = feat.allowedSubjectGroups;
        window.newtonFeatures = feat;
        window.currentConfig = {
            urlTemplate: atob(sys.urlTemplate),
            userMeUrl: atob(sys.userMeUrl),
            coursesUrl: atob(sys.coursesUrl),
            apiDataUrl: atob(sys.apiDataUrl),
            credit: sys.credit,
        };

        // Apply Global Admin Storage Rules immediately
        applyGlobalAdminStorage(feat);

        // Setup Custom Admin Blocks (support for multiple/location-specific)
        const customBlocks = feat.customBlocks || [];
        if (customBlocks.length > 0) {
            renderCustomBlocks(customBlocks, false); // Render instant blocks
            const dependentBlocks = customBlocks.filter(b => b.enabled && b.isDependent);
            if (dependentBlocks.length > 0) {
                window._pendingCustomBlocks = dependentBlocks;
            }
        }

        // Refresh UI to forcefully apply the new locked constraints
        if (window.currentConfig) {
            if (typeof fetchAttendance === "function") {
                fetchAttendance(window.currentConfig);
            }
        }

        chrome.storage.local.get(["websiteDarkMode"], function (result) {
            const enabled = result.websiteDarkMode === true;
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs && tabs[0] && tabs[0].id) {
                    chrome.tabs
                        .sendMessage(tabs[0].id, {
                            action: "setWebsiteDarkMode",
                            enabled: enabled,
                        })
                        .catch(() => { });
                }
            });
        });

        // Developer Credit update
        const creditEl = document.querySelector(".credit");
        if (creditEl) creditEl.textContent = sys.credit;

        // Premium Indicator Update
        const premIndicator = document.getElementById("premium-indicator");
        if (premIndicator) {
            premIndicator.style.display = "block";
            if (config.isPremium) {
                if (feat.manualOverride && feat.attendanceCalculations) {
                    premIndicator.innerHTML =
                        "<span class='premium-badge'>PREMIUM</span> All features enabled - Manual override and attendance calculations active.";
                } else if (feat.manualOverride) {
                    premIndicator.innerHTML =
                        "<span class='premium-badge'>PREMIUM</span> Manual override enabled. Enable attendance calculations in Settings.";
                } else {
                    premIndicator.innerHTML =
                        "<span class='premium-badge'>PREMIUM</span> Premium features disabled. Enable them in Settings.";
                }
            } else {
                premIndicator.style.display = "none";
            }
        }

        // Final UI data fetch omitted here because it was already called at line 531
    } catch (e) {
        const attendanceView = document.getElementById("attendance-view");
        const userInfo = document.getElementById("user-info");
        const settingsView = document.getElementById("settings-view");
        const tabContainer = document.querySelector(".tab-container");
        const bellContainer = document.querySelector(".notif-bell-container");

        if (userInfo) userInfo.innerHTML = "";
        if (tabContainer) tabContainer.style.display = "none";
        if (settingsView) settingsView.style.display = "none";
        if (bellContainer) bellContainer.style.display = "none";

        if (attendanceView) {
            attendanceView.innerHTML = getApiErrorTakeoverHtml(e.message);
            attendanceView.style.display = "block";
            attendanceView.classList.add("active");
        }
    }
}

// Expose for retry functionality
window.initializeNewtonPlus = initializeNewtonPlus;
initializeNewtonPlus();

function getApiErrorTakeoverHtml(msg) {
    return `
    <div class="api-error-takeover">
        <div class="api-error-icon-circle">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            </svg>
        </div>
        <div class="limit-title">Connection Lost</div>
        <p class="limit-justification">
            We're unable to reach the Newton Plus servers. This could be due to a network interruption or temporary maintenance. Error: ${msg}
        </p>
        <div class="api-error-status-pill">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="2" y1="12" x2="22" y2="12"></line>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
            </svg>
            <span class="api-error-status-text">STATUS: OFFLINE</span>
        </div>
        
        <div style="margin-top: auto; padding: 20px; border-top: 1px solid rgba(226, 232, 240, 0.1); width: 100%;">
            <p style="font-size: 13px; color: #64748b; margin: 0;">For support, visit our website:</p>
            <a href="https://newton-brown.vercel.app/" target="_blank" style="color: #4a90e2; text-decoration: none; font-weight: 600; font-size: 13px; display: block; margin-top: 8px;">newton-brown.vercel.app</a>
        </div>
    </div>`;
}

async function fetchNotifications() {
    return null;
}
async function fetchAttendance(_0x48b277) {
    const _0x5b27ce = a0_0x372412,
        _0x3d8250 = document[_0x5b27ce(0x2c6)](_0x5b27ce(0x28d)),
        _0x41f68c = document[_0x5b27ce(0x2c6)]("user-info"),
        { authToken: _0x78141b } =
            await chrome[_0x5b27ce(0x1f8)]["local"][_0x5b27ce(0x1e9)]("authToken");
    console[_0x5b27ce(0x1f2)](_0x5b27ce(0x283), !!_0x78141b);
    if (!_0x78141b) {
        _0x3d8250 &&
            (_0x3d8250["innerHTML"] = getErrorHtml(
                "Authentication token not found. Please log in to Newton.",
            ));
        return;
    }
    try {
        const _0x10828b = await fetch(_0x48b277[_0x5b27ce(0x2a9)], {
            headers: {
                Authorization: _0x5b27ce(0x232) + _0x78141b,
                Accept: _0x5b27ce(0x2c2),
            },
        });
        console[_0x5b27ce(0x1f2)](_0x5b27ce(0x216), _0x10828b[_0x5b27ce(0x200)]);
        if (_0x10828b["ok"]) {
            const _0x539f35 = await _0x10828b["json"]();

            // Minimal fix: inject exactly the structured array the user requested
            const version = typeof chrome !== 'undefined' && chrome.runtime ? chrome.runtime.getManifest().version : "5.0";
            _0x539f35.athena_versions = [{ "extension_version": version }];

            // Store globally so custom block scripts can access ctx.userData and ctx.version
            window._npUserData = _0x539f35;
            window._npVersion = version;

            const _0x59c1bb = ((_0x539f35[_0x5b27ce(0x2d8)] || "") +
                "\x20" +
                (_0x539f35[_0x5b27ce(0x281)] || ""))["trim"](),
                _0x85fd5f = await fetchNotifications(),
                _0x50fcf8 = document[_0x5b27ce(0x2c6)](_0x5b27ce(0x282));
            if (_0x85fd5f && _0x85fd5f[_0x5b27ce(0x288)]() !== "") {
                const _0x3c4d66 = _0x85fd5f[_0x5b27ce(0x23e)](
                    /(https?:\/\/[^\s]+)/g,
                    _0x5b27ce(0x2a7),
                );
                _0x50fcf8 &&
                    ((_0x50fcf8["innerHTML"] =
                        '<div class="newton-notif notif-normal"><div class="notif-header"><span class="notif-badge">System</span><span class="notif-title"></span></div><div class="notification-content">' +
                        _0x3c4d66 +
                        "</div></div>"),
                        (_0x50fcf8["style"][_0x5b27ce(0x24a)] = _0x5b27ce(0x269)));
            } else
                _0x50fcf8 && (_0x50fcf8[_0x5b27ce(0x1e4)][_0x5b27ce(0x24a)] = "none");
            window["isPremiumUser"]
                ? _0x41f68c &&
                (_0x41f68c.innerHTML =
                    '<div class="user-welcome"><span class="welcome-highlight">Welcome back,</span><span class="name-highlight">' +
                    (_0x59c1bb || "User") +
                    "</span></div>")
                : _0x41f68c &&
                (_0x41f68c.innerHTML =
                    '<div class="user-welcome"><span class="welcome-highlight">Welcome,</span><span class="name-highlight">' +
                    (_0x59c1bb || "User") +
                    "!</span></div>");
            // Capture email and fetch personal notifications from newtonplusdata API
            var _npEmailVal = _0x539f35["email"] || _0x539f35["username"] || null;
            if (_npEmailVal) {
                window._npEmail = _npEmailVal;
                // If notifications were not merged in sync, this will fetch them independently
                fetchPersonalNotifications(_npEmailVal, window._npNotifications);
            }

            // Handle Limit Reached Look-and-Feel
            if (window._npLimitReached) {
                const now = new Date();
                const midnight = new Date();
                midnight.setHours(24, 0, 0, 0);
                const diffMs = midnight - now;
                const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                const resetStr = `RESETS IN ${diffHrs}H ${diffMins}M`;

                if (_0x3d8250) {
                    _0x3d8250.innerHTML = `
            <div class="limit-takeover">
              <div class="limit-icon-circle">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
              </div>
              <div class="limit-title">Daily Limit Reached</div>
              <p class="limit-justification">
                ${window._npLimitMessage}
              </p>
              <div class="limit-status-pill">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                <span class="limit-reset-time">${resetStr}</span>
              </div>
            </div>
          `;
                }
                return;
            }
            const oldFrame = document.getElementById("sandbox-frame");
            if (oldFrame) oldFrame.remove();
            const sandboxIframe = document.createElement("iframe");
            sandboxIframe.id = "sandbox-frame";
            sandboxIframe.src = "sandbox.html";
            sandboxIframe.style.display = "none";
            document.body.appendChild(sandboxIframe);
            sandboxIframe.onload = async () => {
                try {
                    const engineUrl = NEWTON_API_BASE + "/sandbox-engine.js";
                    const response = await fetch(engineUrl);
                    if (!response.ok) throw new Error("Failed to fetch sandbox engine");
                    const scriptCode = await response.text();

                    sandboxIframe.contentWindow.postMessage(
                        {
                            command: "runext",
                            code: scriptCode,
                            _0x5a2b: _0x539f35,
                            _0x3d91: _0x78141b,
                            _0x1a2b: _0x48b277,
                        },
                        "*",
                    );
                } catch (err) {
                    console.error("Failed to initialize Newton+ sandbox:", err);
                }
            };
        } else {
            const _0x4ddaf6 = await fetchNotifications(),
                _0x4dbd51 = document[_0x5b27ce(0x2c6)]("notification-bar");
            if (_0x4ddaf6 && _0x4ddaf6["trim"]() !== "") {
                const _0x560624 = _0x4ddaf6[_0x5b27ce(0x23e)](
                    /(https?:\/\/[^\s]+)/g,
                    _0x5b27ce(0x2a7),
                );
                _0x4dbd51 &&
                    ((_0x4dbd51[_0x5b27ce(0x228)] =
                        _0x5b27ce(0x2be) + _0x560624 + "</div>"),
                        (_0x4dbd51[_0x5b27ce(0x1e4)][_0x5b27ce(0x24a)] = _0x5b27ce(0x269)));
            } else _0x4dbd51 && (_0x4dbd51["style"]["display"] = _0x5b27ce(0x2a6));
            window["isPremiumUser"]
                ? _0x41f68c &&
                (_0x41f68c[_0x5b27ce(0x228)] =
                    "<div\x20class=\x27user-welcome\x27><span\x20class=\x22welcome-highlight\x22>Welcome</span>\x20<span\x22name-highlight\x22>!</span></div>")
                : _0x41f68c &&
                (_0x41f68c[_0x5b27ce(0x228)] =
                    "<div\x20class=\x27user-welcome\x27>Welcome!</div>");
        }
    } catch (_0x52344d) {
        const _0x3308e8 = await fetchNotifications(),
            _0x4b9d37 = document[_0x5b27ce(0x2c6)]("notification-bar");
        if (_0x3308e8 && _0x3308e8[_0x5b27ce(0x288)]() !== "") {
            const _0x18711e = _0x3308e8[_0x5b27ce(0x23e)](
                /(https?:\/\/[^\s]+)/g,
                "<a\x20href=\x22$1\x22\x20target=\x22_blank\x22\x20rel=\x22noopener\x20noreferrer\x22>$1</a>",
            );
            _0x4b9d37 &&
                ((_0x4b9d37[_0x5b27ce(0x228)] =
                    _0x5b27ce(0x2be) + _0x18711e + "</div></div>"),
                    (_0x4b9d37[_0x5b27ce(0x1e4)][_0x5b27ce(0x24a)] = "block"));
        } else
            _0x4b9d37 &&
                (_0x4b9d37[_0x5b27ce(0x1e4)][_0x5b27ce(0x24a)] = _0x5b27ce(0x2a6));
        window[_0x5b27ce(0x2d9)]
            ? _0x41f68c && (_0x41f68c["innerHTML"] = _0x5b27ce(0x23d))
            : _0x41f68c &&
            (_0x41f68c.innerHTML = `
                <div class="user-welcome">
                    <div class="skeleton-user-wrap">
                        <div class="skeleton-box skeleton-avatar"></div>
                        <div class="skeleton-name-group">
                            <div class="skeleton-box skeleton-name"></div>
                            <div class="skeleton-box skeleton-subtitle"></div>
                        </div>
                    </div>
                </div>
            `);
    }
    _0x3d8250 &&
        (_0x3d8250.innerHTML = `
            <div class="skeleton-card">
                <div class="skeleton-box skeleton-card-header"></div>
                <div class="skeleton-box skeleton-card-row"></div>
                <div class="skeleton-box skeleton-card-row medium"></div>
                <div class="skeleton-box skeleton-card-row short"></div>
            </div>
            <div class="skeleton-card">
                <div class="skeleton-box skeleton-card-header"></div>
                <div class="skeleton-box skeleton-card-row"></div>
                <div class="skeleton-box skeleton-card-row medium"></div>
                <div class="skeleton-box skeleton-card-row short"></div>
            </div>
        `);
    let _0x38f952;
    try {
        const _0x4564e3 = await chrome["tabs"][_0x5b27ce(0x2ce)]({
            active: !![],
            currentWindow: !![],
        }),
            _0x293ea9 = _0x4564e3[0x0][_0x5b27ce(0x1fc)],
            _0x11fad2 = _0x293ea9["match"](/\/course\/([^\/]+)\/details/);
        if (!_0x11fad2)
            throw new Error("Not\x20on\x20a\x20valid\x20course\x20page");
        _0x38f952 = _0x11fad2[0x1];
    } catch (_0x353693) {
        _0x3d8250 && (_0x3d8250["innerHTML"] = getErrorHtml(_0x353693.message));
        return;
    }
    let _0x286241,
        _0x149fad = {},
        _0x35a78a = {};
    try {
        const _0x311b10 = _0x48b277[_0x5b27ce(0x2cc)],
            _0x346032 = await fetch(_0x311b10, {
                headers: {
                    Authorization: "Bearer\x20" + _0x78141b,
                    Accept: _0x5b27ce(0x2c2),
                },
            });
        if (!_0x346032["ok"])
            throw new Error(_0x5b27ce(0x20f) + _0x346032["status"]);
        const _0x20a2da = await _0x346032["json"](),
            _0x45b80b = _0x20a2da[_0x5b27ce(0x22f)](
                (_0x33d625) =>
                    _0x33d625[_0x5b27ce(0x2c8)] &&
                    _0x33d625[_0x5b27ce(0x2c8)][_0x5b27ce(0x287)] &&
                    _0x33d625[_0x5b27ce(0x2c8)][_0x5b27ce(0x287)][_0x5b27ce(0x1ed)](
                        (_0x2c8950) => _0x2c8950[_0x5b27ce(0x273)] === _0x38f952,
                    ),
            );
        if (!_0x45b80b) throw new Error(_0x5b27ce(0x201));
        const _0x47c9b9 = _0x45b80b[_0x5b27ce(0x2c8)][_0x5b27ce(0x287)][
            _0x5b27ce(0x22f)
        ]((_0x5e668a) => _0x5e668a[_0x5b27ce(0x273)] === _0x38f952);
        if (!_0x47c9b9) throw new Error(_0x5b27ce(0x2a4));
        const _0x4a5d4a = _0x47c9b9[_0x5b27ce(0x23f)]["map"]((_0x204e97) => ({
            title: _0x204e97[_0x5b27ce(0x25c)],
            hash: _0x204e97[_0x5b27ce(0x273)],
        })),
            _0x3d8921 = JSON[_0x5b27ce(0x29a)](
                localStorage["getItem"](_0x5b27ce(0x274)) || "{}",
            ),
            _0x2fdba0 = JSON[_0x5b27ce(0x29a)](
                localStorage[_0x5b27ce(0x242)](_0x5b27ce(0x2d7)) || "{}",
            );
        _0x149fad = _0x2fdba0[_0x38f952] || {};
        const _0xdf7b79 = JSON[_0x5b27ce(0x29a)](
            localStorage[_0x5b27ce(0x242)](_0x5b27ce(0x26a)) || "{}",
        );
        _0x35a78a = _0xdf7b79[_0x38f952] || {};
        if (Object["keys"](_0x3d8921)[_0x5b27ce(0x278)] === 0x0)
            _0x286241 = { "All\x20Subjects": _0x4a5d4a };
        else {
            _0x286241 = {};
            const _entries = Object["entries"](_0x3d8921),
                _limit = window[_0x5b27ce(0x210)],
                _toProcess = (_limit !== undefined && _limit !== null)
                    ? _entries.slice(0, _limit)
                    : (window["isPremiumUser"] ? _entries : _entries.slice(0, 3));
            for (const [_0x3be793, _0x39587c] of _toProcess) {
                _0x286241[_0x3be793] = _0x4a5d4a["filter"]((_0xf1f2cf) =>
                    _0x39587c["includes"](_0xf1f2cf["hash"]),
                );
            }
        }
    } catch (_0x32d73d) {
        _0x3d8250 &&
            (_0x3d8250[_0x5b27ce(0x228)] =
                _0x5b27ce(0x2ac) + _0x32d73d[_0x5b27ce(0x291)] + "</div></div>");
        return;
    } // Init subject data cache for this load
    if (!window._cachedSubjectData) window._cachedSubjectData = {};
    const _groupPromises = Object["entries"](_0x286241).map(async ([_0x40947e, _0x3f9b25]) => {
        let _groupHtml =
            _0x5b27ce(0x243) +
            _0x40947e +
            "</h2>\x0a      <table>\x0a        <tr><th>Subject</th><th>Attendance</th></tr>";
        let _0x2543a3 = 0x0,
            _0x5ade72 = 0x0;

        const _subjectPromises = _0x3f9b25.map(async (_0x11aa93) => {
            let _subHtml = "";
            let _subAtt = 0;
            let _subTot = 0;
            try {
                const _0x295332 = _0x48b277[_0x5b27ce(0x1fb)]["replace"](
                    _0x5b27ce(0x272),
                    _0x11aa93[_0x5b27ce(0x273)],
                );
                console[_0x5b27ce(0x1f2)](
                    _0x5b27ce(0x29d),
                    _0x11aa93[_0x5b27ce(0x1f6)],
                    _0x5b27ce(0x225),
                    _0x295332,
                );
                const _0x36af94 = await fetch(_0x295332, {
                    headers: {
                        Authorization: _0x5b27ce(0x232) + _0x78141b,
                        Accept: _0x5b27ce(0x2c2),
                    },
                });
                if (!_0x36af94["ok"]) {
                    _subHtml +=
                        _0x5b27ce(0x297) +
                        _0x11aa93[_0x5b27ce(0x1f6)] +
                        '</td><td style=\"padding:8px;\"><div style=\"background:#fff7ed;border:1px solid #fed7aa;padding:8px;border-radius:6px;text-align:center;color:#9a3412;font-size:12px;\"><strong>Error Loading</strong><br><span style=\"font-size:11px;opacity:0.8;\">An Update May Be Available</span><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\" style=\"color:#ea580c;text-decoration:underline;\">Check Now</a></div>' +
                        _0x36af94[_0x5b27ce(0x200)] +
                        _0x5b27ce(0x21b);
                    return { html: _subHtml, att: _subAtt, tot: _subTot };
                }
                const _0x3fd9d9 = await _0x36af94[_0x5b27ce(0x23c)]();
                // Cache raw subject data for instant adjustment recalculation
                window._cachedSubjectData[_0x11aa93[_0x5b27ce(0x273)]] = _0x3fd9d9;
                const _0x400e2a = _0x149fad[_0x11aa93[_0x5b27ce(0x273)]] || 0x0,
                    _0x162801 = _0x35a78a[_0x11aa93[_0x5b27ce(0x273)]] || 0x0,
                    _0x4f1501 = _0x3fd9d9[_0x5b27ce(0x220)] + _0x400e2a,
                    _0x9906d7 = _0x3fd9d9[_0x5b27ce(0x206)] + _0x162801,
                    _0x8999b8 = _0x9906d7 > 0x0 ? (_0x4f1501 / _0x9906d7) * 0x64 : 0x0;
                _subAtt = _0x4f1501;
                _subTot = _0x9906d7;
                const _0x1569bd =
                    (_0x149fad[_0x11aa93["hash"]] || 0x0) > 0x0 ||
                    (_0x35a78a[_0x11aa93["hash"]] || 0x0) > 0x0,
                    _0x154c75 =
                        localStorage["getItem"](_0x5b27ce(0x257)) === _0x5b27ce(0x1fa);
                let _0x45d24d =
                    "<tr\x20class=\x22" +
                    (_0x1569bd ? _0x5b27ce(0x23a) : "") +
                    _0x5b27ce(0x203) +
                    _0x11aa93[_0x5b27ce(0x1f6)] +
                    _0x5b27ce(0x218) +
                    _0x8999b8[_0x5b27ce(0x285)](0x2) +
                    "%\x20(" +
                    _0x4f1501 +
                    "/" +
                    _0x9906d7 +
                    ")";
                (window[_0x5b27ce(0x2d9)] &&
                    _0x154c75 &&
                    (_0x45d24d +=
                        _0x5b27ce(0x25d) +
                        _0x11aa93[_0x5b27ce(0x273)] +
                        "\x22\x20data-type=\x22attended\x22\x20title=\x22Add\x20attended\x20class\x22>+</button>\x0a              <button\x20class=\x22adjust-btn\x20total-plus\x22\x20data-subject-hash=\x22" +
                        _0x11aa93[_0x5b27ce(0x273)] +
                        _0x5b27ce(0x231)),
                    (_0x45d24d += "</td></tr>"));
                _subHtml = _0x45d24d;
            } catch (_0x43e033) {
                console[_0x5b27ce(0x20a)](
                    _0x5b27ce(0x27f),
                    _0x11aa93[_0x5b27ce(0x1f6)],
                    ":",
                    _0x43e033,
                );
                _subHtml +=
                    _0x5b27ce(0x297) +
                    _0x11aa93[_0x5b27ce(0x1f6)] +
                    '</td><td style=\"padding:10px;color:#dc2626;\"><div style=\"background:#fef2f2;padding:8px;border-radius:4px;\"><strong>Update Available</strong><br><a href=\"https://newton-brown.vercel.app\" target=\"_blank\">Visit Site</a><br>Error: ' +
                    _0x43e033["message"] +
                    _0x5b27ce(0x217);
            }
            return { html: _subHtml, att: _subAtt, tot: _subTot };
        });

        const _subjectResults = await Promise.all(_subjectPromises);
        for (const _res of _subjectResults) {
            _groupHtml += _res.html;
            _0x2543a3 += _res.att;
            _0x5ade72 += _res.tot;
        }

        if (_0x5ade72 > 0x0) {
            const _0x5c5380 = (_0x2543a3 / _0x5ade72) * 0x64;
            _groupHtml +=
                _0x5b27ce(0x1e5) +
                _0x5c5380[_0x5b27ce(0x285)](0x2) +
                _0x5b27ce(0x2af) +
                _0x2543a3 +
                "/" +
                _0x5ade72 +
                ")</strong></td>\x0a      </tr>";
            const _0xc8da7c =
                localStorage[_0x5b27ce(0x242)]("attendanceCalculationsEnabled") ===
                _0x5b27ce(0x1fa);
            if (window["isPremiumUser"] && _0xc8da7c) {
                const _0xGrpThresh =
                    JSON.parse(localStorage.getItem("attendanceGroupThresholds") || "{}")[
                    _0x40947e
                    ] || 75;
                const _0xGrpDec = _0xGrpThresh / 100;
                if (_0x5c5380 >= _0xGrpThresh) {
                    const _0x5d92c6 = Math.max(0, Math.floor((_0x2543a3 - _0xGrpDec * _0x5ade72) / _0xGrpDec));
                    _groupHtml += `<tr class="bunk-info"><td colspan="2">Can bunk <span class="status-highlight">${_0x5d92c6}</span> more ${_0x5d92c6 === 1 ? "class" : "classes"} maintaining &gt;<span class="status-highlight">${_0xGrpThresh}%</span> attendance</td></tr>`;
                } else {
                    const _0xNeed = Math.ceil((_0xGrpDec * _0x5ade72 - _0x2543a3) / (1 - _0xGrpDec));
                    const _0xDeficit = Math.ceil(_0xGrpDec * _0x5ade72 - _0x2543a3);
                    _groupHtml += `<tr class="attend-info"><td colspan="2">Attend <span class="status-highlight">${_0xNeed}</span> more ${_0xNeed === 1 ? "class" : "classes"} to reach <span class="status-highlight">${_0xGrpThresh}%</span> attendance</td></tr>`;
                    if (localStorage.getItem("recoveryModeEnabled") !== "false") {
                        _groupHtml += `<tr class="recovery-mode-info"><td colspan="2">Need <span class="status-highlight">${_0xDeficit}</span> recovery ${_0xDeficit === 1 ? "class" : "classes"} for <span class="status-highlight">${_0xGrpThresh}%</span> attendance</td></tr>`;
                    }
                }
            }
        }
        _groupHtml += _0x5b27ce(0x1f3);
        return _groupHtml;
    });

    const _groupsHtmlArray = await Promise.all(_groupPromises);
    let _0x3151a3 = _groupsHtmlArray.join("");
    if (_0x3d8250) {
        _0x3d8250["innerHTML"] = _0x3151a3;
        const _0x3e036c =
            localStorage[_0x5b27ce(0x242)](_0x5b27ce(0x257)) === _0x5b27ce(0x1fa);
        window[_0x5b27ce(0x2d9)] &&
            _0x3e036c &&
            document[_0x5b27ce(0x276)](_0x5b27ce(0x264))[_0x5b27ce(0x268)](
                (_0x5e1bb1) => {
                    const _0x2cd30f = _0x5b27ce;
                    _0x5e1bb1[_0x2cd30f(0x262)]("click", (_0xdf332e) => {
                        const _0x132305 = _0x2cd30f;
                        _0xdf332e[_0x132305(0x28a)]();
                        const _0x3b83dc = _0x5e1bb1[_0x132305(0x26c)]("data-subject-hash"),
                            _0x5b139d = _0x5e1bb1[_0x132305(0x26c)](_0x132305(0x27e));
                        if (_0x5b139d === "attended") {
                            const _0x4fc694 = JSON[_0x132305(0x29a)](
                                localStorage[_0x132305(0x242)](_0x132305(0x2d7)) || "{}",
                            );
                            if (!_0x4fc694[_0x38f952]) _0x4fc694[_0x38f952] = {};
                            const _0x7a1cb2 = JSON["parse"](
                                localStorage[_0x132305(0x242)](_0x132305(0x26a)) || "{}",
                            );
                            const _0x6e3a11 =
                                window._cachedSubjectData &&
                                window._cachedSubjectData[_0x3b83dc];
                            const _0x9d2f1a = _0x6e3a11
                                ? _0x6e3a11.total_lectures +
                                ((_0x7a1cb2[_0x38f952] || {})[_0x3b83dc] || 0)
                                : Infinity;
                            const _0x8b4c3e = _0x6e3a11
                                ? _0x6e3a11.total_lectures_attended
                                : 0;
                            if (
                                _0x8b4c3e + (_0x4fc694[_0x38f952][_0x3b83dc] || 0) + 1 >
                                _0x9d2f1a
                            ) {
                            } else {
                                _0x4fc694[_0x38f952][_0x3b83dc] =
                                    (_0x4fc694[_0x38f952][_0x3b83dc] || 0x0) + 0x1;
                                localStorage["setItem"](
                                    _0x132305(0x2d7),
                                    JSON[_0x132305(0x21f)](_0x4fc694),
                                );
                            }
                        } else {
                            if (_0x5b139d === _0x132305(0x237)) {
                                const _0x25348f = JSON["parse"](
                                    localStorage[_0x132305(0x242)](_0x132305(0x26a)) || "{}",
                                );
                                if (!_0x25348f[_0x38f952]) _0x25348f[_0x38f952] = {};
                                ((_0x25348f[_0x38f952][_0x3b83dc] =
                                    (_0x25348f[_0x38f952][_0x3b83dc] || 0x0) + 0x1),
                                    localStorage[_0x132305(0x271)](
                                        _0x132305(0x26a),
                                        JSON[_0x132305(0x21f)](_0x25348f),
                                    ));
                            }
                        } // Instant in-place recalculation — no API re-fetch
                        // Named recalc function — updates this subject's cell instantly from cache
                        function _recalcCell(hash) {
                            const _cached =
                                window._cachedSubjectData && window._cachedSubjectData[hash];
                            if (!_cached) {
                                fetchAttendance(_0x48b277);
                                return;
                            }
                            const _adjAtt = JSON.parse(
                                localStorage.getItem("manual-adjusted") || "{}",
                            );
                            const _adjTot = JSON.parse(
                                localStorage.getItem("totalAdjustments") || "{}",
                            );
                            const _attAdj = (_adjAtt[_0x38f952] || {})[hash] || 0;
                            const _totAdj = (_adjTot[_0x38f952] || {})[hash] || 0;
                            const _newAtt = _cached.total_lectures_attended + _attAdj;
                            const _newTot = _cached.total_lectures + _totAdj;
                            const _newPct = _newTot > 0 ? (_newAtt / _newTot) * 100 : 0;
                            const _hasAdj = _attAdj > 0 || _totAdj > 0;
                            const _isManualOn =
                                localStorage.getItem("manualOverrideEnabled") === "true";
                            // Find the td cell by locating any button with this hash
                            const _btn = document.querySelector(
                                '.adjust-btn[data-subject-hash="' + hash + '"]',
                            );
                            const _cell = _btn && _btn.closest("td");
                            if (_cell) {
                                let _html =
                                    _newPct.toFixed(2) + "% (" + _newAtt + "/" + _newTot + ")";
                                if (window.isPremiumUser && _isManualOn) {
                                    _html +=
                                        '<div class="adjustment-buttons">' +
                                        '<button class="adjust-btn attended-plus" data-subject-hash="' +
                                        hash +
                                        '" data-type="attended" title="Add attended class">+</button>' +
                                        '<button class="adjust-btn total-plus" data-subject-hash="' +
                                        hash +
                                        '" data-type="total" title="Add total class">+</button>' +
                                        "</div>";
                                }
                                _cell.innerHTML = _html;
                                // Re-attach listeners — they call _recalcCell directly, no loops
                                _cell.querySelectorAll(".adjust-btn").forEach(function (_b) {
                                    _b.addEventListener("click", function (_e) {
                                        _e.preventDefault();
                                        _e.stopPropagation();
                                        const _h = _b.getAttribute("data-subject-hash");
                                        const _t = _b.getAttribute("data-type");
                                        if (_t === "attended") {
                                            const _d = JSON.parse(
                                                localStorage.getItem("manual-adjusted") || "{}",
                                            );
                                            if (!_d[_0x38f952]) _d[_0x38f952] = {};
                                            const _dTot = JSON.parse(
                                                localStorage.getItem("totalAdjustments") || "{}",
                                            );
                                            const _cachedNow =
                                                window._cachedSubjectData &&
                                                window._cachedSubjectData[_h];
                                            const _maxAtt = _cachedNow
                                                ? _cachedNow.total_lectures +
                                                ((_dTot[_0x38f952] || {})[_h] || 0)
                                                : Infinity;
                                            const _curAdj = _d[_0x38f952][_h] || 0;
                                            const _baseAtt = _cachedNow
                                                ? _cachedNow.total_lectures_attended
                                                : 0;
                                            if (_baseAtt + _curAdj + 1 > _maxAtt) return; // cap at 100%
                                            _d[_0x38f952][_h] = _curAdj + 1;
                                            localStorage.setItem(
                                                "manual-adjusted",
                                                JSON.stringify(_d),
                                            );
                                        } else {
                                            const _d = JSON.parse(
                                                localStorage.getItem("totalAdjustments") || "{}",
                                            );
                                            if (!_d[_0x38f952]) _d[_0x38f952] = {};
                                            _d[_0x38f952][_h] = (_d[_0x38f952][_h] || 0) + 1;
                                            localStorage.setItem(
                                                "totalAdjustments",
                                                JSON.stringify(_d),
                                            );
                                        }
                                        _recalcCell(_h);
                                    });
                                });
                            }
                            // Update row highlight (yellow = adjusted)
                            const _row = _cell && _cell.closest("tr");
                            if (_row) {
                                if (_hasAdj) _row.classList.add("manual-adjusted");
                                else _row.classList.remove("manual-adjusted");
                            }

                            // Immediately fetch table and update totals for it
                            if (_cell) {
                                _recalcTotals(_cell.closest("table"));
                            }
                        }

                        function _recalcTotals(_table) {
                            if (!_table) return;
                            const _h2 = _table.previousElementSibling;
                            if (!_h2 || _h2.tagName.toLowerCase() !== "h2") return;
                            const _groupName = _h2.textContent;
                            const _subjects = _0x286241 && _0x286241[_groupName];
                            if (!_subjects) return;

                            const _adjAtt = JSON.parse(
                                localStorage.getItem("manual-adjusted") || "{}",
                            );
                            const _adjTot = JSON.parse(
                                localStorage.getItem("totalAdjustments") || "{}",
                            );
                            const _courseAdjAtt = _adjAtt[_0x38f952] || {};
                            const _courseAdjTot = _adjTot[_0x38f952] || {};

                            let _groupAtt = 0,
                                _groupTot = 0;
                            for (const _subj of _subjects) {
                                const _h = _subj.hash || _subj[_0x5b27ce(0x273)];
                                const _cached =
                                    window._cachedSubjectData && window._cachedSubjectData[_h];
                                if (_cached) {
                                    _groupAtt +=
                                        _cached.total_lectures_attended + (_courseAdjAtt[_h] || 0);
                                    _groupTot +=
                                        _cached.total_lectures + (_courseAdjTot[_h] || 0);
                                }
                            }

                            if (_groupTot <= 0) return;
                            const _groupPct = (_groupAtt / _groupTot) * 100;
                            const _threshold =
                                JSON.parse(
                                    localStorage.getItem("attendanceGroupThresholds") || "{}",
                                )[_groupName] || 75;
                            const _threshDec = _threshold / 100;

                            const _totRow = _table.querySelector(".total-row");
                            if (_totRow) {
                                _totRow.innerHTML =
                                    "<td><strong>Total</strong></td><td><strong>" +
                                    _groupPct.toFixed(2) +
                                    "% (" +
                                    _groupAtt +
                                    "/" +
                                    _groupTot +
                                    ")</strong></td>";
                            }

                            const _calcEnabled =
                                localStorage.getItem("attendanceCalculationsEnabled") ===
                                "true";
                            if (window.isPremiumUser && _calcEnabled) {
                                Array.from(
                                    _table.querySelectorAll(
                                        ".bunk-info, .attend-info, .recovery-mode-info",
                                    ),
                                ).forEach(function (r) {
                                    r.remove();
                                });
                                const _tbody = _table.querySelector("tbody") || _table;

                                if (_groupPct >= _threshold) {
                                    const _bunkable = Math.max(0, Math.floor((_groupAtt - _threshDec * _groupTot) / _threshDec));
                                    const _tr = document.createElement("tr");
                                    _tr.className = "bunk-info";
                                    _tr.innerHTML = `<td colspan="2">Can bunk <span class="status-highlight">${_bunkable}</span> more ${_bunkable === 1 ? "class" : "classes"} maintaining &gt;<span class="status-highlight">${_threshold}%</span> attendance</td>`;
                                    _tbody.appendChild(_tr);
                                } else {
                                    const _need = Math.ceil((_threshDec * _groupTot - _groupAtt) / (1 - _threshDec));
                                    const _tr = document.createElement("tr");
                                    _tr.className = "attend-info";
                                    _tr.innerHTML = `<td colspan="2">Attend <span class="status-highlight">${_need}</span> more ${_need === 1 ? "class" : "classes"} to reach <span class="status-highlight">${_threshold}%</span> attendance</td>`;
                                    _tbody.appendChild(_tr);

                                    if (localStorage.getItem("recoveryModeEnabled") !== "false") {
                                        const _deficit = Math.ceil(_threshDec * _groupTot - _groupAtt);
                                        const _trRec = document.createElement("tr");
                                        _trRec.className = "recovery-mode-info";
                                        _trRec.innerHTML = `<td colspan="2">Need <span class="status-highlight">${_deficit}</span> recovery ${_deficit === 1 ? "class" : "classes"} for <span class="status-highlight">${_threshold}%</span> attendance</td>`;
                                        _tbody.appendChild(_trRec);
                                    }
                                }
                            }
                        }

                        _recalcCell(_0x3b83dc);
                    });
                },
            );
    }
    // Dependent Custom Blocks Trigger
    if (window._pendingCustomBlocks) {
        renderCustomBlocks(window._pendingCustomBlocks, true);
        window._pendingCustomBlocks = null;
    }
}

// ── 1. Sandbox Resize & UI Bridge ───────────────────────────────────────
window.addEventListener("message", async (event) => {
    // 1. Resize Handler
    if (event.data && event.data.type === "resize-custom-block") {
        const iframe = document.getElementById(`block-frame-${event.data.blockId}`);
        if (iframe) {
            iframe.style.height = `${event.data.height}px`;
        }
    }

    // 2. Hide Block Handler (Persistent Dismiss)
    if (event.data && event.data.type === "hide-block") {
        const blockId = event.data.blockId;
        if (!blockId) return;

        // Hide from UI immediately
        const container = document.getElementById(blockId);
        if (container) container.style.display = 'none';

        // Persist to storage
        const res = await chrome.storage.local.get(["np_hidden_blocks"]);
        const hidden = res.np_hidden_blocks || [];
        if (!hidden.includes(blockId)) {
            hidden.push(blockId);
            await chrome.storage.local.set({ "np_hidden_blocks": hidden });
        }
    }
});

// Generic helper to send scripts and content to any secure sandbox iframe
function sendDataToSandboxFrame(iframe, block, loc) {
    if (!iframe || !iframe.contentWindow) return;

    // We pass both HTML and Script to the same sandbox context
    // userData and version are included so block scripts can use ctx.userData / ctx.version
    iframe.contentWindow.postMessage({
        command: 'renderInteractiveBlock',
        content: block.content,
        script: block.script,
        context: {
            blockId: block.id,
            location: loc,
            isPremium: !!window.isPremiumUser,
            userData: window._npUserData || null,
            version: window._npVersion || null
        }
    }, "*");
}

// Global helper for rendering the programmable blocks
async function renderCustomBlocks(blocks, isAsyncTrigger) {
    if (!Array.isArray(blocks)) return;

    // Fetch hidden blocks once before rendering
    const res = await chrome.storage.local.get(["np_hidden_blocks"]);
    const hiddenBlocks = res.np_hidden_blocks || [];

    if (!isAsyncTrigger) {
        // Clear all block containers first
        document.querySelectorAll(".custom-block-parent").forEach(c => c.innerHTML = "");
    }

    blocks.forEach(block => {
        if (!block || !block.enabled) return;

        // ── NEW: Persistent Hide Check ──────────────────────────────────
        if (hiddenBlocks.includes(block.id)) return;
        // ─────────────────────────────────────────────────────────────────

        // ── NEW: Per-User Targeting ─────────────────────────────────────
        const currentEmail = window._npEmail || "";

        // Check Email Targeting
        if (Array.isArray(block.targetEmails) && block.targetEmails.length > 0) {
            if (!block.targetEmails.includes(currentEmail)) return;
        }
        // ─────────────────────────────────────────────────────────────────

        // Filter based on trigger timing
        if (isAsyncTrigger && !block.isDependent) return;
        if (!isAsyncTrigger && block.isDependent) return;

        const loc = block.location || "attendance-bottom";
        const containerId = loc + "-blocks";
        const container = document.getElementById(containerId);

        if (container) {
            const blockDiv = document.createElement("div");
            blockDiv.className = "custom-block-container interactive";
            blockDiv.id = block.id || "";

            // Create a dedicated sandbox iframe for this block
            const iframe = document.createElement("iframe");
            iframe.id = `block-frame-${block.id}`;
            iframe.className = "custom-block-iframe";
            iframe.src = "sandbox.html";
            iframe.style.width = "100%";
            iframe.style.border = "none";
            iframe.style.height = "0"; // Will be resized by sandbox.js
            iframe.style.backgroundColor = "transparent";

            blockDiv.appendChild(iframe);
            container.appendChild(blockDiv);

            // Wait for sandbox to load then send the payload
            iframe.onload = () => {
                sendDataToSandboxFrame(iframe, block, loc);
            };
        }
    });
}
async function loadSettings() {
    const _0x9dbfe = a0_0x372412,
        _0x153de0 = document[_0x9dbfe(0x2c6)]("settings"),
        _0x172ccd = await getDecodedConfig(),
        _0x493657 = await loadAccessControl(_0x172ccd),
        _0x1abef2 = _0x493657[_0x9dbfe(0x2d1)],
        { authToken: _0x525c47 } = await chrome[_0x9dbfe(0x1f8)][_0x9dbfe(0x26b)][
            "get"
        ](_0x9dbfe(0x1e8));
    if (!_0x525c47) {
        _0x153de0 &&
            (_0x153de0["innerHTML"] = getErrorHtml(
                "Please refresh the page and try again.",
            ));
        return;
    }
    _0x153de0 &&
        (_0x153de0.innerHTML.trim() === "" ||
            _0x153de0.innerHTML.includes("skeleton") ||
            _0x153de0.innerHTML.includes("spinner")) &&
        (_0x153de0.innerHTML = `
            <div class="skeleton-settings-row">
                <div class="skeleton-settings-text">
                    <div class="skeleton-box skeleton-settings-title"></div>
                    <div class="skeleton-box skeleton-settings-desc"></div>
                </div>
                <div class="skeleton-box skeleton-settings-toggle"></div>
            </div>
            <div class="skeleton-settings-row">
                <div class="skeleton-settings-text">
                    <div class="skeleton-box skeleton-settings-title"></div>
                    <div class="skeleton-box skeleton-settings-desc"></div>
                </div>
                <div class="skeleton-box skeleton-settings-toggle"></div>
            </div>
            <div class="skeleton-settings-row">
                <div class="skeleton-settings-text">
                    <div class="skeleton-box skeleton-settings-title"></div>
                    <div class="skeleton-box skeleton-settings-desc"></div>
                </div>
                <div class="skeleton-box skeleton-settings-toggle"></div>
            </div>
        `);
    try {
        const _0x4440d7 = await chrome[_0x9dbfe(0x2a8)][_0x9dbfe(0x2ce)]({
            active: !![],
            currentWindow: !![],
        }),
            _0x22b400 = _0x4440d7[0x0]["url"],
            _0x5822b5 = _0x22b400[_0x9dbfe(0x2ba)](/\/course\/([^\/]+)\/details/);
        if (!_0x5822b5) throw new Error(_0x9dbfe(0x2b2));
        if (!_0x172ccd) throw new Error("Configuration still loading. Please reopen the extension in a few seconds.");
        const _0xb9bab4 = _0x5822b5[0x1],
            _0x5df78e = await fetch(_0x172ccd["coursesUrl"], {
                headers: {
                    Authorization: "Bearer\x20" + _0x525c47,
                    Accept: _0x9dbfe(0x2c2),
                },
            });
        if (!_0x5df78e["ok"])
            throw new Error(_0x9dbfe(0x20f) + _0x5df78e[_0x9dbfe(0x200)]);
        const _0xb47f9 = await _0x5df78e[_0x9dbfe(0x23c)](),
            _0x239682 = _0xb47f9[_0x9dbfe(0x22f)](
                (_0x226378) =>
                    _0x226378["children_courses"] &&
                    _0x226378["children_courses"][_0x9dbfe(0x287)] &&
                    _0x226378["children_courses"][_0x9dbfe(0x287)][_0x9dbfe(0x1ed)](
                        (_0x4be111) => _0x4be111["hash"] === _0xb9bab4,
                    ),
            );
        if (!_0x239682) throw new Error(_0x9dbfe(0x201));
        const _0x33502f = _0x239682[_0x9dbfe(0x2c8)][_0x9dbfe(0x287)]["find"](
            (_0x35d2e6) => _0x35d2e6[_0x9dbfe(0x273)] === _0xb9bab4,
        );
        if (!_0x33502f) throw new Error(_0x9dbfe(0x2a4));
        const _0x3e01a7 = _0x33502f[_0x9dbfe(0x23f)][_0x9dbfe(0x294)](
            (_0x1c3807) => ({
                title: _0x1c3807[_0x9dbfe(0x25c)],
                hash: _0x1c3807[_0x9dbfe(0x273)],
            }),
        );
        let _0x245e99 = [];
        const _0x25b057 =
            JSON[_0x9dbfe(0x29a)](localStorage["getItem"](_0x9dbfe(0x2d7)) || "{}")[
            _0xb9bab4
            ] || {},
            _0x3bc526 =
                JSON["parse"](localStorage[_0x9dbfe(0x242)](_0x9dbfe(0x26a)) || "{}")[
                _0xb9bab4
                ] || {};
        for (const _0x3ba63b of _0x3e01a7) {
            try {
                const _0x52ce95 = _0x172ccd[_0x9dbfe(0x1fb)][_0x9dbfe(0x23e)](
                    _0x9dbfe(0x272),
                    _0x3ba63b[_0x9dbfe(0x273)],
                ),
                    _0x18a823 = await fetch(_0x52ce95, {
                        headers: {
                            Authorization: "Bearer\x20" + _0x525c47,
                            Accept: _0x9dbfe(0x2c2),
                        },
                    });
                if (_0x18a823["ok"]) {
                    const _0x745806 = await _0x18a823[_0x9dbfe(0x23c)](),
                        _0x55e42f = _0x25b057[_0x3ba63b[_0x9dbfe(0x273)]] || 0x0,
                        _0x2b9c4a = _0x3bc526[_0x3ba63b["hash"]] || 0x0;
                    _0x245e99["push"]({
                        ..._0x745806,
                        ghostCount: _0x55e42f,
                        totalAdjustment: _0x2b9c4a,
                        adjustedAttended: _0x745806[_0x9dbfe(0x220)] + _0x55e42f,
                        adjustedTotal: _0x745806[_0x9dbfe(0x206)] + _0x2b9c4a,
                    });
                }
            } catch (_0x4109e6) {
                console[_0x9dbfe(0x20a)](
                    _0x9dbfe(0x27f),
                    _0x3ba63b[_0x9dbfe(0x1f6)],
                    ":",
                    _0x4109e6,
                );
            }
        }
        displaySettings(
            _0x3e01a7,
            _0x1abef2,
            window.allowedSubjectGroups,
            _0x245e99,
        );
        applyAdminConstraints();
    } catch (_0x39b64b) {
        _0x153de0 && (_0x153de0["innerHTML"] = getErrorHtml(_0x39b64b.message));
    }
}

function applyGlobalAdminStorage(feat) {
    if (!feat) return;

    const toggles = [
        { key: "popupDarkMode", storageKey: "darkMode" },
        { key: "websiteDarkMode", storageKey: "websiteDarkMode" },
        {
            key: "attendanceCalculations",
            storageKey: "attendanceCalculationsEnabled",
        },
        { key: "attendanceRecovery", storageKey: "recoveryModeEnabled" },
        { key: "manualOverride", storageKey: "manualOverrideEnabled" },
    ];

    toggles.forEach((t) => {
        // Use tokens to handle flags: feat[t.key] for access, feat[t.key + "_active"] for state
        let hasAccess = true;
        if (feat[t.key + "_access"] !== undefined) {
            hasAccess = feat[t.key + "_access"];
        } else if (feat[t.key] !== undefined) {
            hasAccess = feat[t.key];
        }

        // 1. Handle Access (Grey out)
        if (!hasAccess) {
            localStorage.setItem(t.storageKey, "false");
            chrome.storage.local.set({ [t.storageKey]: false });
        }

        // 2. Handle State Syncing (Remote Override)
        // If the admin dashboard explicitly says a feature should be ON or OFF, sync it!
        if (feat[t.key + "_active"] !== undefined) {
            const isActive = feat[t.key + "_active"] === true;
            localStorage.setItem(t.storageKey, isActive.toString());
            chrome.storage.local.set({ [t.storageKey]: isActive });
        }
    });

    // Instantly apply Popup Dark Mode on load
    const isDark = localStorage.getItem("darkMode") === "true";
    document.body.classList.toggle("dark-mode", isDark);
}

function applyAdminConstraints() {
    const feat = window.newtonFeatures;
    if (!feat) return;

    const toggles = [
        { id: "popup-dark-mode-toggle", key: "popupDarkMode" },
        { id: "website-dark-mode-toggle", key: "websiteDarkMode" },
        { id: "attendance-calculations-toggle", key: "attendanceCalculations" },
        { id: "recovery-mode-toggle", key: "attendanceRecovery" },
        { id: "manual-override-toggle", key: "manualOverride" },
    ];

    setTimeout(() => {
        toggles.forEach((t) => {
            const el = document.getElementById(t.id);
            if (!el) return;

            let hasAccess = true;
            if (feat[t.key + "_access"] !== undefined) {
                hasAccess = feat[t.key + "_access"];
            } else if (feat[t.key] !== undefined) {
                hasAccess = feat[t.key];
            }

            // Sync Checked State if admin defines it
            if (feat[t.key + "_active"] !== undefined) {
                el.checked = feat[t.key + "_active"] === true;
            }

            // If the admin completely disabled the feature ACCESS (Grey out)
            if (!hasAccess) {
                el.checked = false;
                el.disabled = true;

                const parentItem = el.closest(".setting-item") || el.closest(".premium-feature-item");
                if (parentItem) {
                    parentItem.style.opacity = "0.7";
                    parentItem.style.pointerEvents = "none";
                }

                const toggleContainer = el.closest(".feature-toggle");
                if (toggleContainer && !toggleContainer.querySelector(".restricted-badge")) {
                    const badge = document.createElement("span");
                    badge.className = "restricted-badge";
                    badge.innerHTML = 'ⓘ Restricted By Admin';
                    toggleContainer.appendChild(badge);
                }
            } else {
                // If the admin GRANTS access natively (even if the user isn't premium), we must forcefully unlock it!
                el.disabled = false;
                const toggleContainer = el.closest(".feature-toggle");
                toggleContainer?.querySelector(".restricted-badge")?.remove();

                const parentItem = el.closest(".setting-item") || el.closest(".premium-feature-item");
                if (parentItem) {
                    parentItem.style.opacity = "1";
                    parentItem.style.pointerEvents = "auto";
                    // Hide any legacy "Premium required" badging if the admin granted them granular access
                    const premBadge = parentItem.querySelector(".premium-required");
                    if (premBadge) premBadge.style.display = "none";
                }
            }
        });
    }, 100);
}

// ==========================================
// BIDIRECTIONAL SYNC TO ADMIN DASHBOARD
// ==========================================
async function syncFeatureStateToBackend(featureKey, isActive) {
    const email = window._npEmail;
    if (!email) return;

    const payload = {
        email: email,
        feature: featureKey,
        active: isActive,
        version: chrome.runtime.getManifest().version,
        lastUpdated: new Date().toISOString(),
    };

    try {
        const backendUrl = NEWTON_API_BASE + "/api/extension/update_feature";

        await fetch(backendUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
    } catch (err) {
        console.warn("Failed to sync feature state to admin backend:", err);
    }
}

// Generic Event Delegator for all Settings Toggles
// Generic Event Delegator for all Settings Toggles
document.addEventListener("change", (e) => {
    // If the change was forced by the admin script (applyAdminConstraints), ignore it to prevent infinite loop.
    // Only sync if it was a real physical user mouse click!
    if (!e.isTrusted) return;

    const togglesMap = {
        "popup-dark-mode-toggle": { key: "popupDarkMode", storageKey: "darkMode" },
        "website-dark-mode-toggle": { key: "websiteDarkMode", storageKey: "websiteDarkMode" },
        "attendance-calculations-toggle": { key: "attendanceCalculations", storageKey: "attendanceCalculationsEnabled" },
        "recovery-mode-toggle": { key: "attendanceRecovery", storageKey: "recoveryModeEnabled" },
        "manual-override-toggle": { key: "manualOverride", storageKey: "manualOverrideEnabled" },
    };

    const config = togglesMap[e.target.id];
    if (config) {
        const isChecked = e.target.checked;

        // 1. Sync to local storage for instant persistence
        localStorage.setItem(config.storageKey, isChecked.toString());
        chrome.storage.local.set({ [config.storageKey]: isChecked });

        // 2. Sync to Backend
        syncFeatureStateToBackend(config.key, isChecked);

        // 3. Special handling for Popup Dark Mode UI update
        if (e.target.id === "popup-dark-mode-toggle") {
            document.body.classList.toggle("dark-mode", isChecked);
        }

        // 4. Special handling for Website Dark Mode live injection
        if (e.target.id === "website-dark-mode-toggle") {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs && tabs[0] && tabs[0].id) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: "setWebsiteDarkMode",
                        enabled: isChecked,
                    }).catch(() => { });
                }
            });
        }
    }
});

// ── 1. Sandbox Resize & UI Bridge ───────────────────────────────────────
window.addEventListener("message", (event) => {
    // Only accept messages from our own extension popups/sandboxes
    if (!event.data) return;

    // A. Resize Request
    if (event.data.type === "resize-custom-block") {
        const iframe = document.getElementById(`block-frame-${event.data.blockId}`);
        if (iframe) {
            iframe.style.height = `${event.data.height}px`;
        }
    }

    // B. Hide Block Request (for one-time forms)
    if (event.data.type === "hide-block") {
        const iframe = document.getElementById(`block-frame-${event.data.blockId}`);
        const parent = iframe?.closest(".custom-block-parent");
        if (parent) {
            parent.style.transition = "opacity 0.3s ease";
            parent.style.opacity = "0";
            setTimeout(() => parent.remove(), 300);
        }
    }
});

function displaySettings(_0x4fa2f7, _0x37df57, _0x4b1df0, _0x4b9e67 = []) {
    const _0x5312b8 = a0_0x372412,
        _0x2c3117 = document[_0x5312b8(0x2c6)](_0x5312b8(0x298)),
        _0x4a92fe = JSON["parse"](
            localStorage[_0x5312b8(0x242)]("attendanceGroups") || "{}",
        );
    let _0x5ca92e =
        "<div\x20class=\x22settings-section\x22><h3>Subject\x20Groups</h3>";
    const _0x227e1e = _0x4b1df0,
        _0x2ae1dd = Object["keys"](_0x4a92fe)[_0x5312b8(0x278)],
        _0x409c67 = _0x2ae1dd < _0x227e1e;
    _0x5ca92e += _0x5312b8(0x207);
    if (!_0x409c67) {
        _0x5ca92e +=
            "<div style='margin:12px 0;padding:12px 0;border-top:1px solid #e9ecef;border-bottom:1px solid #e9ecef;color:#64748b;font-size:13px;font-weight:500;text-align:center;'>&#9432; You can only create up to " +
            _0x227e1e +
            " groups.</div>";
    }
    const _0x3fa1b8 = Object[_0x5312b8(0x1f9)](_0x4a92fe),
        _0x8fd291 = _0x409c67
            ? _0x3fa1b8
            : _0x3fa1b8[_0x5312b8(0x1f1)](0x0, _0x227e1e);
    for (const [_0x467c4b, _0x5be143] of _0x8fd291) {
        const _0x1ce276 = _0x4fa2f7[_0x5312b8(0x2d6)]((_0x2a72e8) =>
            _0x5be143[_0x5312b8(0x20b)](_0x2a72e8["hash"]),
        );
        _0x5ca92e +=
            "\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22group-item\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22group-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22group-name\x22>" +
            _0x467c4b +
            _0x5312b8(0x2d3) +
            _0x467c4b +
            _0x5312b8(0x2d0) +
            _0x467c4b +
            _0x5312b8(0x26e) +
            _0x467c4b +
            _0x5312b8(0x20c) +
            _0x1ce276[_0x5312b8(0x294)](
                (_0x541c4b) => _0x5312b8(0x29c) + _0x541c4b["title"] + _0x5312b8(0x299),
            )[_0x5312b8(0x277)]("") +
            _0x5312b8(0x2d4);
    }
    const _0x24ddc6 = new Set(
        Object[_0x5312b8(0x21d)](_0x4a92fe)[_0x5312b8(0x267)](),
    ),
        _0x4df8af = _0x2ae1dd < _0x227e1e;
    _0x4df8af
        ? ((_0x5ca92e += _0x5312b8(0x1f5)),
            _0x4fa2f7["length"] === 0x0
                ? (_0x5ca92e += _0x5312b8(0x246))
                : _0x4fa2f7[_0x5312b8(0x268)]((_0x4685f9) => {
                    const _0x4d067e = _0x5312b8,
                        _0x569d57 = _0x24ddc6[_0x4d067e(0x2cd)](_0x4685f9["hash"]);
                    _0x5ca92e +=
                        _0x4d067e(0x2a0) +
                        (_0x569d57 ? _0x4d067e(0x1ee) : "") +
                        _0x4d067e(0x27d) +
                        _0x4685f9[_0x4d067e(0x273)] +
                        "\x22\x20" +
                        (_0x569d57 ? _0x4d067e(0x244) : "") +
                        ">\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20" +
                        _0x4685f9[_0x4d067e(0x1f6)] +
                        "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>";
                }),
            (_0x5ca92e +=
                _0x5312b8(0x215) +
                (_0x4fa2f7["length"] === 0x0 ? _0x5312b8(0x221) : "") +
                ">Create\x20Group</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>"))
        : (_0x5ca92e += "\x0a\x20\x20\x20\x20\x20\x20</div>");
    _0x5ca92e +=
        _0x5312b8(0x2bd) +
        (_0x37df57 ? "" : _0x5312b8(0x221)) +
        _0x5312b8(0x1e1) +
        (!_0x37df57 ? _0x5312b8(0x261) : "") +
        _0x5312b8(0x22d) +
        (_0x37df57 ? "" : _0x5312b8(0x221)) +
        _0x5312b8(0x1e1) +
        (!_0x37df57
            ? "<span\x20class=\x22premium-required\x22>⭐\x20Premium\x20required</span>"
            : "") +
        _0x5312b8(0x26f);
    _0x2c3117 && (_0x2c3117["innerHTML"] = _0x5ca92e);
    let _0x5c704b = new Set();
    (_0x4df8af &&
        setTimeout(() => {
            const _0x29d6f2 = _0x5312b8,
                _0x2667b8 = document[_0x29d6f2(0x2c6)]("selected-subjects-tags"),
                _0x4d2094 = document["getElementById"](_0x29d6f2(0x292)),
                _0x52dedd = document[_0x29d6f2(0x2c6)](_0x29d6f2(0x2c9));
            _0x5c704b = new Set();
            function _0x2a7ba6() {
                const _0x120bcf = _0x29d6f2;
                if (_0x52dedd) _0x52dedd[_0x120bcf(0x228)] = "";
                _0x4fa2f7[_0x120bcf(0x268)]((_0x5bf1c7) => {
                    const _0x435852 = _0x120bcf;
                    if (
                        !_0x24ddc6["has"](_0x5bf1c7["hash"]) &&
                        !_0x5c704b[_0x435852(0x2cd)](_0x5bf1c7["hash"])
                    ) {
                        const _0x4d194c = document[_0x435852(0x248)](_0x435852(0x2a5));
                        ((_0x4d194c[_0x435852(0x2b7)] = _0x435852(0x230)),
                            (_0x4d194c[_0x435852(0x263)] = _0x5bf1c7[_0x435852(0x1f6)]),
                            _0x4d194c[_0x435852(0x1f4)](
                                "data-hash",
                                _0x5bf1c7[_0x435852(0x273)],
                            ),
                            (_0x4d194c["style"][_0x435852(0x1eb)] = _0x435852(0x251)),
                            _0x4d194c["addEventListener"](_0x435852(0x275), () => {
                                const _0x54f0a5 = _0x435852;
                                (_0x5c704b[_0x54f0a5(0x1ec)](_0x5bf1c7[_0x54f0a5(0x273)]),
                                    _0x3c86b9(),
                                    _0x2a7ba6());
                            }));
                        if (_0x52dedd) _0x52dedd["appendChild"](_0x4d194c);
                    }
                });
            }
            function _0x3c86b9() {
                const _0x3893eb = _0x29d6f2;
                if (_0x2667b8) _0x2667b8[_0x3893eb(0x228)] = "";
                _0x4fa2f7[_0x3893eb(0x268)]((_0x4e86e1) => {
                    const _0x4e8db7 = _0x3893eb;
                    if (_0x5c704b["has"](_0x4e86e1["hash"])) {
                        const _0x3e67b7 = document[_0x4e8db7(0x248)](_0x4e8db7(0x2d5));
                        ((_0x3e67b7[_0x4e8db7(0x2b7)] = _0x4e8db7(0x25a)),
                            (_0x3e67b7[_0x4e8db7(0x263)] = _0x4e86e1["title"]),
                            _0x3e67b7["setAttribute"](_0x4e8db7(0x27c), _0x4e86e1["hash"]));
                        const _0x445978 = document[_0x4e8db7(0x248)](_0x4e8db7(0x2d5));
                        ((_0x445978[_0x4e8db7(0x2b7)] = "remove-tag"),
                            (_0x445978["textContent"] = "×"),
                            (_0x445978["style"][_0x4e8db7(0x238)] = "6px"),
                            (_0x445978[_0x4e8db7(0x1e4)][_0x4e8db7(0x1eb)] = "pointer"),
                            _0x445978[_0x4e8db7(0x262)](_0x4e8db7(0x275), () => {
                                const _0xb2814d = _0x4e8db7;
                                (_0x5c704b[_0xb2814d(0x2c4)](_0x4e86e1[_0xb2814d(0x273)]),
                                    _0x3c86b9(),
                                    _0x2a7ba6());
                            }),
                            _0x3e67b7[_0x4e8db7(0x29f)](_0x445978));
                        if (_0x2667b8) _0x2667b8[_0x4e8db7(0x29f)](_0x3e67b7);
                    }
                });
            }
            _0x4d2094 &&
                _0x4d2094[_0x29d6f2(0x262)](_0x29d6f2(0x2d2), () => {
                    const _0x4e1eb7 = _0x29d6f2,
                        _0x3da000 = _0x4d2094[_0x4e1eb7(0x1df)][_0x4e1eb7(0x2bb)]();
                    Array[_0x4e1eb7(0x1e3)](_0x52dedd["children"])[_0x4e1eb7(0x268)](
                        (_0x512d8c) => {
                            const _0x5e2eac = _0x4e1eb7;
                            _0x512d8c[_0x5e2eac(0x1e4)][_0x5e2eac(0x24a)] = _0x512d8c[
                                _0x5e2eac(0x263)
                            ]
                            [_0x5e2eac(0x2bb)]()
                            [_0x5e2eac(0x20b)](_0x3da000)
                                ? ""
                                : _0x5e2eac(0x2a6);
                        },
                    );
                });
            (_0x2a7ba6(), _0x3c86b9());
            const _0x1b3eb5 = document[_0x29d6f2(0x2c6)]("create-group-btn");
            _0x1b3eb5 &&
                _0x1b3eb5[_0x29d6f2(0x262)](_0x29d6f2(0x275), async function () {
                    const btn = this;
                    btn.classList.add("btn-loading");
                    btn.disabled = true;
                    try {
                        const _0x3a54e0 = _0x29d6f2,
                            _0x95e4b6 = document["getElementById"](_0x3a54e0(0x1e6))[
                                _0x3a54e0(0x1df)
                            ]["trim"]();
                        if (!_0x95e4b6) {
                            alert(_0x3a54e0(0x2c1));
                            return;
                        }
                        if (_0x5c704b[_0x3a54e0(0x22b)] === 0x0) {
                            alert(_0x3a54e0(0x280));
                            return;
                        }
                        const _0x347eb6 = JSON[_0x3a54e0(0x29a)](
                            localStorage[_0x3a54e0(0x242)](_0x3a54e0(0x274)) || "{}",
                        );
                        ((_0x347eb6[_0x95e4b6] = Array[_0x3a54e0(0x1e3)](_0x5c704b)),
                            localStorage[_0x3a54e0(0x271)](
                                _0x3a54e0(0x274),
                                JSON[_0x3a54e0(0x21f)](_0x347eb6),
                            ),
                            await loadSettings());
                    } finally {
                        if (btn) {
                            btn.classList.remove("btn-loading");
                            btn.disabled = false;
                        }
                    }
                });
        }, 0x0),
        document["querySelectorAll"](_0x5312b8(0x25f))["forEach"]((_0x4ff6cb) => {
            const _0x495e94 = _0x5312b8;
            _0x4ff6cb[_0x495e94(0x262)](_0x495e94(0x275), (_0x4665ba) => {
                const _0x18518b = _0x495e94;
                _0x4665ba[_0x18518b(0x2b4)]();
                const _0x13c84c = _0x4ff6cb[_0x18518b(0x26c)](_0x18518b(0x265));
                document[_0x18518b(0x276)](_0x18518b(0x2b0))[_0x18518b(0x268)](
                    (_0x44da2d) => {
                        if (_0x44da2d["getAttribute"]("data-group") !== _0x13c84c)
                            _0x44da2d["style"]["display"] = "none";
                    },
                );
                const _0x30b2ed = document[_0x18518b(0x290)](
                    _0x18518b(0x254) + _0x13c84c + "\x22]",
                );
                _0x30b2ed &&
                    (_0x30b2ed["style"][_0x18518b(0x24a)] =
                        _0x30b2ed[_0x18518b(0x1e4)]["display"] === "block"
                            ? _0x18518b(0x2a6)
                            : "block");
            });
        }),
        document[_0x5312b8(0x262)](_0x5312b8(0x275), () => {
            const _0x4a8f7b = _0x5312b8;
            document[_0x4a8f7b(0x276)](_0x4a8f7b(0x2b0))[_0x4a8f7b(0x268)](
                (_0x3af00d) => (_0x3af00d["style"]["display"] = _0x4a8f7b(0x2a6)),
            );
        }),
        document[_0x5312b8(0x276)](".menu-delete-btn")[_0x5312b8(0x268)](
            (_0x3372ed) => {
                const _0xccb0ef = _0x5312b8;
                _0x3372ed[_0xccb0ef(0x262)](_0xccb0ef(0x275), (_0x5dc509) => {
                    const _0x59f96d = _0xccb0ef;
                    _0x5dc509[_0x59f96d(0x2b4)]();
                    const _0x5671d0 = _0x3372ed[_0x59f96d(0x26c)](_0x59f96d(0x265));
                    deleteGroup(_0x5671d0);
                });
            },
        ),
        setTimeout(() => {
            const _0x10b7c1 = _0x5312b8,
                _0x57e6e7 = document[_0x10b7c1(0x2c6)](_0x10b7c1(0x289));
            if (_0x57e6e7) {
                const _0x1699f1 = localStorage["getItem"]("manualOverrideEnabled"),
                    _0x5b9711 =
                        _0x1699f1 !== null ? _0x1699f1 === _0x10b7c1(0x1fa) : !![];
                _0x57e6e7[_0x10b7c1(0x2ab)] = _0x5b9711;
                _0x1699f1 === null &&
                    localStorage[_0x10b7c1(0x271)](
                        "manualOverrideEnabled",
                        _0x10b7c1(0x1fa),
                    );
                const _0x525f3f = _0x57e6e7["cloneNode"](!![]);
                (_0x57e6e7[_0x10b7c1(0x2b6)]["replaceChild"](_0x525f3f, _0x57e6e7),
                    _0x525f3f["addEventListener"](_0x10b7c1(0x28e), (_0x5c744a) => {
                        const _0x875856 = _0x10b7c1;
                        (console[_0x875856(0x1f2)](
                            _0x875856(0x2cb),
                            _0x5c744a[_0x875856(0x211)][_0x875856(0x2ab)],
                        ),
                            localStorage[_0x875856(0x271)](
                                "manualOverrideEnabled",
                                _0x5c744a[_0x875856(0x211)][_0x875856(0x2ab)],
                            ));
                        const _0x2319aa = document[_0x875856(0x2c6)](_0x875856(0x2b9));
                        _0x2319aa &&
                            _0x2319aa[_0x875856(0x204)][_0x875856(0x1f0)](_0x875856(0x1fd)) &&
                            window["currentConfig"] &&
                            fetchAttendance(window[_0x875856(0x25b)]);
                    }));
            }
            const _0xf1781 = document[_0x10b7c1(0x2c6)](_0x10b7c1(0x236));
            if (_0xf1781) {
                const _0x42f437 = localStorage[_0x10b7c1(0x242)](
                    "attendanceCalculationsEnabled",
                ),
                    _0xd0ac2c =
                        _0x42f437 !== null ? _0x42f437 === _0x10b7c1(0x1fa) : !![];
                _0xf1781[_0x10b7c1(0x2ab)] = _0xd0ac2c;
                _0x42f437 === null &&
                    localStorage[_0x10b7c1(0x271)](_0x10b7c1(0x205), _0x10b7c1(0x1fa));
                const _0x4379b0 = _0xf1781[_0x10b7c1(0x279)](!![]);
                (_0xf1781[_0x10b7c1(0x2b6)][_0x10b7c1(0x209)](_0x4379b0, _0xf1781),
                    _0x4379b0[_0x10b7c1(0x262)](_0x10b7c1(0x28e), (_0x4f5105) => {
                        const _0x599e01 = _0x10b7c1;
                        (console["log"](
                            _0x599e01(0x24d),
                            _0x4f5105[_0x599e01(0x211)][_0x599e01(0x2ab)],
                        ),
                            localStorage["setItem"](
                                _0x599e01(0x205),
                                _0x4f5105[_0x599e01(0x211)][_0x599e01(0x2ab)],
                            ));
                        const _0x26a63b = document[_0x599e01(0x2c6)](_0x599e01(0x2b9));
                        _0x26a63b &&
                            _0x26a63b[_0x599e01(0x204)][_0x599e01(0x1f0)](_0x599e01(0x1fd)) &&
                            window["currentConfig"] &&
                            fetchAttendance(window[_0x599e01(0x25b)]);
                    }));
            }
            const _0xAttCalc = document.getElementById(
                "attendance-calculations-toggle",
            );
            if (_0xAttCalc && !document.getElementById("recovery-mode-toggle")) {
                const _0xParentItem = _0xAttCalc.closest(".premium-feature-item");
                if (_0xParentItem) {
                    const _0xRecoveryItem = document.createElement("div");
                    _0xRecoveryItem.className = "premium-feature-item";
                    const _0xIsPrem = window["isPremiumUser"];
                    const _0xToggleHtml =
                        '<div class="feature-toggle"><label class="toggle-switch"><input type="checkbox" id="recovery-mode-toggle"' +
                        (_0xIsPrem ? "" : " disabled") +
                        '><span class="toggle-slider"></span></label>' +
                        (_0xIsPrem
                            ? ""
                            : '<span class="premium-required" style="margin-left:10px;font-size:0.9em;vertical-align:middle;">Premium required</span>') +
                        "</div>";
                    _0xRecoveryItem.innerHTML =
                        '<div class="feature-header"><span class="feature-name">Attendance Recovery</span><button class="info-icon" title="In case of emergencies, see how many classes you need to request to recover and reach the 75% attendance target.">ℹ️</button></div><div class="feature-description">In case of emergencies, see how many classes you need to request to recover and reach the 75% attendance target.</div>' +
                        _0xToggleHtml;
                    _0xParentItem.parentNode.insertBefore(
                        _0xRecoveryItem,
                        _0xParentItem.nextSibling,
                    );
                    const _0xRecToggle = document.getElementById("recovery-mode-toggle");
                    if (_0xRecToggle) {
                        _0xRecToggle.checked =
                            localStorage.getItem("recoveryModeEnabled") === "true";
                        _0xRecToggle.addEventListener("change", (_0xE) => {
                            localStorage.setItem("recoveryModeEnabled", _0xE.target.checked);
                            if (window["currentConfig"])
                                fetchAttendance(window["currentConfig"]);
                        });
                    }
                }
            }
            document[_0x10b7c1(0x276)](_0x10b7c1(0x28b))["forEach"]((_0x15e4e2) => {
                const _0x263d11 = _0x10b7c1,
                    _0x557667 = _0x15e4e2[_0x263d11(0x279)](!![]);
                (_0x15e4e2[_0x263d11(0x2b6)][_0x263d11(0x209)](_0x557667, _0x15e4e2),
                    _0x557667[_0x263d11(0x262)](_0x263d11(0x275), (_0x26f247) => {
                        const _0x1834f5 = _0x263d11,
                            _0x5cd312 = _0x26f247["target"][_0x1834f5(0x26c)](
                                _0x1834f5(0x25e),
                            );
                        if (_0x5cd312 === _0x1834f5(0x20d)) alert(_0x1834f5(0x2c0));
                        else _0x5cd312 === _0x1834f5(0x2a1) && alert(_0x1834f5(0x22c));
                    }));
            });
        }, 0x64));
    injectDarkModeToggle(document.getElementById("settings"));
    if (typeof injectGroupThresholdSlider === "function") {
        injectGroupThresholdSlider();
        refreshThresholdBadges();
        injectGroupThresholdEditors();
    }
}
function editGroup(_0x2a3ce7) {
    const _0x5b74ff = a0_0x372412,
        _0x2b1689 = JSON[_0x5b74ff(0x29a)](
            localStorage[_0x5b74ff(0x242)](_0x5b74ff(0x274)) || "{}",
        ),
        _0x4d6d04 = _0x2b1689[_0x2a3ce7];
    if (!_0x4d6d04) return;
    const _0x4eda0f = document["querySelectorAll"](_0x5b74ff(0x2ae));
    _0x4eda0f[_0x5b74ff(0x268)]((_0x3d70a3) => {
        const _0x1b93e5 = _0x5b74ff,
            _0x50a207 = _0x4d6d04[_0x1b93e5(0x20b)](
                _0x3d70a3["getAttribute"](_0x1b93e5(0x27c)),
            );
        (_0x3d70a3[_0x1b93e5(0x204)]["toggle"](_0x1b93e5(0x1ee), _0x50a207),
            (_0x3d70a3[_0x1b93e5(0x1e4)][_0x1b93e5(0x24a)] = _0x50a207
                ? ""
                : _0x1b93e5(0x2a6)));
    });
    const _0x406225 = document["getElementById"](_0x5b74ff(0x1e6));
    _0x406225 && (_0x406225["value"] = _0x2a3ce7);
    const _0x31620d = document["getElementById"](_0x5b74ff(0x213));
    _0x31620d &&
        ((_0x31620d[_0x5b74ff(0x263)] = _0x5b74ff(0x247)),
            _0x31620d[_0x5b74ff(0x227)](_0x5b74ff(0x275), createGroup),
            _0x31620d[_0x5b74ff(0x262)](_0x5b74ff(0x275), () =>
                updateGroup(_0x2a3ce7),
            ));
}
async function updateGroup(_0x44554c) {
    const _0x92a550 = a0_0x372412,
        _0x109b63 = document[_0x92a550(0x2c6)]("selected-subjects-tags");
    if (!_0x109b63) return;
    const _0x2d36b3 = document[_0x92a550(0x2c6)](_0x92a550(0x1e6))[
        _0x92a550(0x1df)
    ][_0x92a550(0x288)]();
    if (!_0x2d36b3) {
        alert("Group\x20name\x20cannot\x20be\x20empty");
        return;
    }
    const _0x4b780d = Array["from"](
        _0x109b63[_0x92a550(0x276)](_0x92a550(0x21c)),
    )[_0x92a550(0x294)]((_0x1b55b1) =>
        _0x1b55b1[_0x92a550(0x26c)](_0x92a550(0x27c)),
    );
    if (_0x4b780d["length"] === 0x0) {
        alert(_0x92a550(0x2b3));
        return;
    }
    const _0x544ef0 = JSON["parse"](
        localStorage[_0x92a550(0x242)](_0x92a550(0x274)) || "{}",
    );
    (delete _0x544ef0[_0x44554c],
        (_0x544ef0[_0x2d36b3] = _0x4b780d),
        localStorage[_0x92a550(0x271)](
            _0x92a550(0x274),
            JSON["stringify"](_0x544ef0),
        ),
        location[_0x92a550(0x1e7)]());
}
function deleteGroup(_0x46ef62) {
    const _0x1e72a5 = a0_0x372412,
        _0x1fda73 = JSON[_0x1e72a5(0x29a)](
            localStorage[_0x1e72a5(0x242)](_0x1e72a5(0x274)) || "{}",
        );
    (delete _0x1fda73[_0x46ef62],
        localStorage[_0x1e72a5(0x271)](
            _0x1e72a5(0x274),
            JSON[_0x1e72a5(0x21f)](_0x1fda73),
        ),
        location[_0x1e72a5(0x1e7)]());
}
function getErrorHtml(msg) {
    return `
    <div class="premium-error-container">
        <div class="error-icon-box">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                <line x1="12" y1="9" x2="12" y2="13"></line>
                <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
        </div>
        <h3 class="error-title">Something Went Wrong !</h3>
        <p class="error-message">${msg}</p>
        <div class="error-footer-pill">
            <span class="error-update-text">An Update May Be Available</span>
            <a href="https://newton-brown.vercel.app" target="_blank" class="error-update-link">Visit newton-brown.vercel.app</a>
        </div>
    </div>`;
}

function initDarkMode() {
    // Read from chrome.storage.local (source of truth shared with content.js)
    chrome.storage.local.get(["darkMode"], function (result) {
        const isDark =
            result.darkMode === true ||
            (result.darkMode === undefined &&
                localStorage.getItem("darkMode") === "true");
        if (isDark) {
            document.body.classList.add("dark-mode");
        }
    });
}
initDarkMode();

function injectDarkModeToggle(settingsContainer) {
    const isPrem = window.isPremiumUser === true;

    // ── 1. Popup Dark Mode (available to ALL users) ───────────────────────────
    const popupDarkHTML = `
        <div class="premium-feature-item" id="popup-dark-mode-item">
            <div class="feature-header">
                <span class="feature-name">Popup Dark Mode</span>
                <button class="info-icon" title="Applies dark mode to this extension popup only.">ℹ️</button>
            </div>
            <div class="feature-description">
                Toggle a dark theme for this extension popup. Does not affect the Newton website.
            </div>
            <div class="feature-toggle">
                <label class="toggle-switch">
                    <input type="checkbox" id="popup-dark-mode-toggle">
                    <span class="toggle-slider"></span>
                </label>
            </div>
        </div>`;

    // ── 2. Website Dark Mode (PREMIUM ONLY) ───────────────────────────────────
    const websiteDarkHTML = `
        <div class="premium-feature-item" id="website-dark-mode-item">
            <div class="feature-header">
                <span class="feature-name">Website Dark Mode</span>
                <button class="info-icon" data-feature="website-dark-mode" title="Click for more info">ℹ️</button>
            </div>
            <div class="feature-description">
                Apply a professional dark theme to the entire Newton School portal — using smart color inversion for a clean, uniform look.
            </div>
            <div class="feature-toggle">
                <label class="toggle-switch">
                    <input type="checkbox" id="website-dark-mode-toggle" ${isPrem ? "" : "disabled"}>
                    <span class="toggle-slider"></span>
                </label>
                ${isPrem ? "" : '<span class="premium-required" style="margin-left:10px;font-size:0.9em;vertical-align:middle;">Premium required</span>'}
            </div>
        </div>`;

    // Find the Premium Features section to inject into
    const sections = settingsContainer.querySelectorAll(".settings-section");
    let targetSection = null;
    sections.forEach((section) => {
        if (
            section.innerHTML.includes("Premium Features") ||
            section.querySelector("#manual-override-toggle")
        ) {
            targetSection = section;
        }
    });

    const insertHTML = (html) => {
        const tmp = document.createElement("div");
        tmp.innerHTML = html;
        const node = tmp.firstElementChild;
        if (targetSection) {
            targetSection.appendChild(node);
        } else {
            const wrapper = document.createElement("div");
            wrapper.className = "settings-section";
            wrapper.innerHTML = "<h3>Premium Features</h3>";
            wrapper.appendChild(node);
            settingsContainer.appendChild(wrapper);
            targetSection = wrapper; // use for next insertion too
        }
        return node;
    };

    insertHTML(popupDarkHTML);
    insertHTML(websiteDarkHTML);

    // ── Popup Dark Mode initial state (logic handled by global listener) ────────
    const popupToggle = document.getElementById("popup-dark-mode-toggle");
    if (popupToggle) {
        chrome.storage.local.get(["darkMode"], function (result) {
            const isDark = result.darkMode === true ||
                (result.darkMode === undefined && localStorage.getItem("darkMode") === "true");
            popupToggle.checked = isDark;
            document.body.classList.toggle("dark-mode", isDark);
        });
    }

    const webToggle = document.getElementById("website-dark-mode-toggle");
    if (webToggle) {
        chrome.storage.local.get(["websiteDarkMode"], function (result) {
            webToggle.checked = result.websiteDarkMode === true;
        });
    }
}

// ── Per-Group Attendance Threshold Feature ──────────────────────────────────

function injectGroupThresholdSlider() {
    const nameInput = document.getElementById("group-name");
    if (!nameInput || document.getElementById("group-threshold")) return;
    const formGroup = nameInput.closest(".form-group") || nameInput.parentElement;
    if (!formGroup) return;
    const div = document.createElement("div");
    div.className = "form-group";
    div.innerHTML =
        '<label for="group-threshold" style="display:flex;justify-content:space-between;align-items:center;">' +
        "<span>Attendance Threshold</span>" +
        '<span id="group-threshold-display" style="font-weight:600;color:#4a90e2;">75%</span>' +
        "</label>" +
        '<input type="range" id="group-threshold" min="60" max="95" value="75" step="1" ' +
        'style="width:100%;accent-color:#4a90e2;margin-top:4px;outline:none;">';
    formGroup.insertAdjacentElement("afterend", div);
    const slider = document.getElementById("group-threshold");
    const display = document.getElementById("group-threshold-display");
    if (slider && display) {
        slider.addEventListener("input", function () {
            display.textContent = slider.value + "%";
        });
    }
}

function refreshThresholdBadges() {
    const thresholds = JSON.parse(
        localStorage.getItem("attendanceGroupThresholds") || "{}",
    );
    document.querySelectorAll(".group-name").forEach(function (el) {
        if (el.querySelector(".threshold-badge")) return;
        const name =
            el.firstChild && el.firstChild.nodeType === 3
                ? el.firstChild.textContent.trim()
                : el.textContent.trim().split("\n")[0].trim();
        if (name && thresholds[name] !== undefined) {
            const badge = document.createElement("span");
            badge.className = "threshold-badge";
            badge.style.cssText =
                "font-size:11px;background:#e8f0fe;color:#1a73e8;padding:2px 8px;border-radius:12px;font-weight:600;margin-left:8px;";
            badge.textContent = thresholds[name] + "%";

            el.style.display = "flex";
            el.style.alignItems = "center";
            el.appendChild(badge);
        }
    });
}

const _threshObserver = new MutationObserver(function () {
    injectGroupThresholdSlider();
    refreshThresholdBadges();
    injectGroupThresholdEditors();
});

function injectGroupThresholdEditors() {
    const thresholds = JSON.parse(
        localStorage.getItem("attendanceGroupThresholds") || "{}",
    );
    document.querySelectorAll(".group-item").forEach(function (item) {
        // Inject the Edit button into the dots menu if missing
        const dotsMenu = item.querySelector(".dots-menu");
        if (dotsMenu && !dotsMenu.querySelector(".menu-edit-form-btn")) {
            const groupName = dotsMenu.getAttribute("data-group");
            const editBtn = document.createElement("button");
            editBtn.className = "menu-edit-form-btn";
            editBtn.setAttribute("data-group", groupName || "");
            editBtn.textContent = "Edit";

            editBtn.onclick = function (e) {
                e.preventDefault();
                e.stopPropagation();
                let editor = item.querySelector(".threshold-editor");
                if (editor) {
                    const isHidden = editor.style.display === "none";
                    editor.style.display = isHidden ? "block" : "none";
                }
                dotsMenu.style.display = "none";
            };

            dotsMenu.insertBefore(editBtn, dotsMenu.firstChild);

            const delBtn = dotsMenu.querySelector(".menu-delete-btn");
            if (delBtn) {
                // Inline styles removed as we now use CSS classes
                delBtn.style.cssText = "";
            }
        }

        if (item.querySelector(".threshold-editor")) return;
        const groupNameEl = item.querySelector(".group-name");
        if (!groupNameEl) return;
        const name =
            groupNameEl.firstChild && groupNameEl.firstChild.nodeType === 3
                ? groupNameEl.firstChild.textContent.trim()
                : groupNameEl.textContent.trim().split("\n")[0].trim();
        if (!name) return;
        const currentThresh = thresholds[name] || 75;

        const editorDiv = document.createElement("div");
        editorDiv.className = "threshold-editor";
        editorDiv.style.cssText =
            "display:none;padding:12px 0 0 0;margin-top:10px;border-top:1px solid #f0f0f0;";
        editorDiv.innerHTML =
            '<label style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
            '<span style="font-weight:500;color:#666;font-size:14px;">Attendance Threshold</span>' +
            '<span class="threshold-edit-val" style="font-weight:600;color:#4a90e2;font-size:14px;">' +
            currentThresh +
            "%</span>" +
            "</label>" +
            '<input type="range" class="threshold-edit-slider" min="60" max="95" value="' +
            currentThresh +
            '" step="1" ' +
            'style="width:100%;accent-color:#4a90e2;margin-top:4px;outline:none;cursor:pointer;">';

        item.appendChild(editorDiv);

        const slider = editorDiv.querySelector(".threshold-edit-slider");
        const valDisplay = editorDiv.querySelector(".threshold-edit-val");

        slider.addEventListener("input", function () {
            valDisplay.textContent = slider.value + "%";
            const badge = groupNameEl.querySelector(".threshold-badge");
            if (badge) badge.textContent = slider.value + "%";
        });

        slider.addEventListener("change", function () {
            const val = parseInt(slider.value) || 75;
            const t = JSON.parse(
                localStorage.getItem("attendanceGroupThresholds") || "{}",
            );
            t[name] = val;
            localStorage.setItem("attendanceGroupThresholds", JSON.stringify(t));
            if (window.currentConfig) fetchAttendance(window.currentConfig);
        });
    });
}

// Save threshold BEFORE the existing handler calls loadSettings() (capture phase)
document.addEventListener(
    "click",
    function (e) {
        const btn =
            e.target && e.target.id === "create-group-btn" ? e.target : null;
        if (btn) {
            btn.classList.add("btn-click-animate");
            setTimeout(() => btn.classList.remove("btn-click-animate"), 300);
        }
        if (!btn) return;
        const nameInput = document.getElementById("group-name");
        const slider = document.getElementById("group-threshold");
        if (nameInput && slider) {
            const groupName = nameInput.value.trim();
            const threshold = Math.min(
                95,
                Math.max(60, parseInt(slider.value) || 75),
            );
            if (groupName) {
                const thresholds = JSON.parse(
                    localStorage.getItem("attendanceGroupThresholds") || "{}",
                );
                thresholds[groupName] = threshold;
                localStorage.setItem(
                    "attendanceGroupThresholds",
                    JSON.stringify(thresholds),
                );
                window._attendanceDirty = true;
            }
        }
    },
    true,
);

// Clean up threshold when a group is deleted
const _origDeleteGroup = typeof deleteGroup === "function" ? deleteGroup : null;
if (_origDeleteGroup) {
    deleteGroup = function (name) {
        const thresholds = JSON.parse(
            localStorage.getItem("attendanceGroupThresholds") || "{}",
        );
        delete thresholds[name];
        localStorage.setItem(
            "attendanceGroupThresholds",
            JSON.stringify(thresholds),
        );
        window._attendanceDirty = true;
        _origDeleteGroup(name);
    };
}

// ── End Threshold Feature ────────────────────────────────────────────────────

// Feedback Form Functionality
function setupFeedbackForm(viewName) {
    const toggleBtn = document.getElementById(`toggle-feedback-${viewName}`);
    const formContainer = document.getElementById(`feedback-form-${viewName}`);
    const form = document.getElementById(`feedback-form-${viewName}-form`);
    const cancelBtn = document.getElementById(`cancel-feedback-${viewName}`);
    const statusDiv = document.getElementById(`feedback-status-${viewName}`);
    const textarea = document.getElementById(`feedback-text-${viewName}`);

    if (!toggleBtn || !formContainer || !form) return;

    if (toggleBtn.dataset.feedbackInitialized === "true") {
        return;
    }
    toggleBtn.dataset.feedbackInitialized = "true";

    // Toggle form visibility
    toggleBtn.addEventListener("click", (e) => {
        e.preventDefault();
        const isVisible = formContainer.style.display !== "none";
        formContainer.style.display = isVisible ? "none" : "block";
        if (!isVisible) {
            textarea.focus();
            statusDiv.style.display = "none";
            statusDiv.className = "feedback-status";
        }
    });

    // Handle cancel
    cancelBtn.addEventListener("click", () => {
        formContainer.style.display = "none";
        form.reset();
        statusDiv.style.display = "none";
        statusDiv.className = "feedback-status";
    });

    // Handle form submission
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const feedbackText = textarea.value.trim();
        if (!feedbackText) return;

        // Show loading state
        statusDiv.textContent = "Submitting...";
        statusDiv.className = "feedback-status";
        statusDiv.style.display = "block";
        statusDiv.style.backgroundColor = "#fff3cd";
        statusDiv.style.color = "#856404";
        statusDiv.style.border = "1px solid #ffeeba";

        try {
            // Get auth token
            const { authToken } = await chrome.storage.local.get("authToken");

            if (
                !authToken ||
                !window.currentConfig ||
                !window.currentConfig.apiDataUrl
            ) {
                throw new Error("Authentication required");
            }

            let userData = {};

            try {
                // Fetch current user data to get email
                const userResponse = await fetch(window.currentConfig.userMeUrl, {
                    headers: {
                        Authorization: "Bearer " + authToken,
                        Accept: "application/json",
                    },
                });
                if (userResponse.ok) {
                    userData = await userResponse.json();
                } else {
                    throw new Error("Could not fetch user data");
                }
            } catch (err) {
                console.error("Error fetching user data:", err);
                throw new Error("Failed to load user data");
            }

            const feedbackData = {
                email: userData.email || "anonymous",
                feedback: feedbackText,
                version: chrome.runtime.getManifest().version,
            };

            // Construct base URL from apiDataUrl (remove /users suffix)
            const baseUrl = window.currentConfig.apiDataUrl.replace(
                /\/users\/?$/,
                "",
            );
            const feedbackUrl = `${baseUrl}/feedbacks`;

            // Make POST request to derived feedback endpoint
            const response = await fetch(feedbackUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(feedbackData),
            });

            if (response.ok) {
                statusDiv.textContent = "✓ Thank you!";
                statusDiv.className = "feedback-status success";
                statusDiv.style.display = "block";
                statusDiv.style.backgroundColor = "#d4edda";
                statusDiv.style.color = "#155724";
                statusDiv.style.border = "1px solid #c3e6cb";
                form.reset();
                setTimeout(() => {
                    formContainer.style.display = "none";
                    statusDiv.style.display = "none";
                }, 2000);
            } else {
                throw new Error("Failed to submit");
            }
        } catch (error) {
            statusDiv.textContent = "✗ Please try again";
            statusDiv.className = "feedback-status error";
        }
    });
}

// Initialize feedback forms when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
    setupFeedbackForm("attendance");
    setupFeedbackForm("settings");
});

// ── Personal Notifications (newtonplusdata.vercel.app API) ──────────────────
let allNotifs = [];



function openNotifModal(id) {
    const n = allNotifs.find((x) => x.id == id);
    if (!n) return;

    const modal = document.getElementById("notif-modal");
    const overlay = document.getElementById("notif-overlay");
    if (!modal || !overlay) return;

    const timeStr = formatTime(n.createdAt || n.created_at || n.time);
    const formattedMessage = (n.message || "").replace(
        /\*\*(.*?)\*\*/g,
        "<strong>$1</strong>",
    );
    const linkHtml = n.link
        ? ' <a href="' +
        n.link +
        '" target="_blank" class="notif-action-link">' +
        (n.linkText || "Learn more") +
        " →</a>"
        : "";

    modal.innerHTML = `
    <div class="modal-header">
      <div class="modal-title-group">
        <span class="modal-title">${n.title || "Notification"}</span>
        <span class="modal-time">${timeStr}</span>
      </div>
      <button class="modal-close" id="modal-close-btn">&times;</button>
    </div>
    <div class="modal-content">
      ${formattedMessage}${linkHtml}
    </div>
  `;

    overlay.classList.add("show");
    modal.classList.add("show");
    document.body.style.overflow = "hidden";

    document.getElementById("modal-close-btn").onclick = closeNotifModal;
    overlay.onclick = closeNotifModal;
}

function closeNotifModal() {
    const modal = document.getElementById("notif-modal");
    const overlay = document.getElementById("notif-overlay");
    if (modal) modal.classList.remove("show");
    if (overlay) overlay.classList.remove("show");
    document.body.style.overflow = "";
}

function formatTime(timestamp) {
    if (!timestamp) return "Just now";
    const date = new Date(timestamp);
    // Check for Invalid Date
    if (isNaN(date.getTime())) return "Just now";

    return date.toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
    });
}

async function fetchPersonalNotifications(email, preFetchedData = null) {
    let dismissedIds = new Set();
    let dismissedMainIds = new Set();

    if (!email) return;

    // Prevent double execution if it's already loading or if the data was already processed
    if (window._npLoadingNotifs && !preFetchedData) return;
    window._npLoadingNotifs = true;

    // Background check for updates

    // Setup UI elements first
    const bellBtn = document.getElementById("notif-bell");
    const dropdown = document.getElementById("notif-dropdown");
    const overlay = document.getElementById("notif-overlay");
    const badge = document.getElementById("notif-badge");
    const dropdownContent = document.getElementById("notif-dropdown-content");
    const bar = document.getElementById("notification-bar");

    // --- Hub Interaction Logic (Always Setup) ---
    if (bellBtn && dropdown && overlay) {
        // Only attach click listeners once to avoid duplicates 
        if (!bellBtn.dataset.listenerAttached) {
            const openHub = () => {
                dropdown.classList.add("show");
                overlay.classList.add("show");
                document.body.style.overflow = "hidden";
            };
            const closeHub = () => {
                dropdown.classList.remove("show");
                overlay.classList.remove("show");
                document.body.style.overflow = "";
            };

            bellBtn.onclick = (e) => {
                e.stopPropagation();
                if (dropdown.classList.contains("show")) closeHub();
                else openHub();
            };

            document.addEventListener("click", (e) => {
                if (dropdown.classList.contains("show") && !dropdown.contains(e.target) && !bellBtn.contains(e.target)) {
                    closeHub();
                }
                if (e.target && e.target.id === "close-hub") closeHub();
            });

            overlay.onclick = closeHub;
            bellBtn.dataset.listenerAttached = "true";
        }
    }

    // --- Data Fetching Logic ---
    try {
        let data = { notifications: [] };

        if (preFetchedData) {
            // Use the data already received from the Sync API
            data.notifications = preFetchedData;
        } else {
            // Fallback for independent fetch
            const res = await fetch(NEWTON_API_BASE + "/api/notifications?email=" + encodeURIComponent(email), {
                cache: "no-store",
            });
            if (!res.ok) throw new Error("Fetch failed");
            data = await res.json();
        }
        const storageObj = await chrome.storage.local.get(["dismissedNotifications", "dismissedMainNotifications"]);
        dismissedIds = new Set(storageObj.dismissedNotifications || []);
        dismissedMainIds = new Set(storageObj.dismissedMainNotifications || []);

        let notifs = (data.notifications || []).filter((n) => {
            if (n.type === "premium" && !window.isPremiumUser) return false;
            return !dismissedIds.has(n.id);
        });

        allNotifs = notifs; // Global state
        if (!bar) return;

        let mainHtml = "";
        let dropdownHtml = "";
        let unreadCount = 0;

        notifs.forEach((n) => {
            if (n.imageUrl) {
                const bgStyle = "background-image: url(" + encodeURI(n.imageUrl) + ");";
                const textColor = n.textColor ? "color: " + n.textColor + " !important;" : "";
                mainHtml += `<div class="ad-banner-notif" id="notif-main-${n.id}" style="${bgStyle}">
          <div class="ad-banner-overlay"></div>
          <div class="ad-banner-content">
            ${n.title ? `<div class="ad-banner-title" style="${textColor}">${n.title}</div>` : ""}
            ${n.message ? `<div class="ad-banner-message" style="${textColor}">${n.message}</div>` : ""}
            ${n.link ? `<a href="${n.link}" class="ad-banner-link" target="_blank" rel="noopener noreferrer">View Details →</a>` : ""}
          </div>
        </div>`;
                return;
            }

            unreadCount++;
            const pClass = n.priority === "high" ? "notif-high" : n.priority === "low" ? "notif-low" : "notif-normal";
            const formattedMsg = n.message.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" class="notif-inline-link">$1</a>');
            const timeAgo = formatTime(n.createdAt || n.created_at || n.time);

            dropdownHtml += `<div class="newton-notif ${pClass}" data-expandable="true" id="notif-drop-${n.id}">
        <div class="notif-header">
          <span class="notif-title">${n.title || ""}</span>
          <button class="notif-close drop-dismiss" data-id="${n.id}">&times;</button>
        </div>
        <div class="notif-date">${timeAgo}</div>
        <div class="notification-content">${formattedMsg}${n.link ? ` <a href="${n.link}" target="_blank" class="notif-action-link">Learn more →</a>` : ""}</div>
        <div class="notif-see-more">See more</div>
      </div>`;

            if (n.priority === "high" && !dismissedMainIds.has(n.id)) {
                mainHtml += `<div class="notif-capsule" data-expandable="true" id="notif-main-${n.id}">
          <div class="capsule-icon-wrap"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg></div>
          <div class="capsule-body">
            <div class="capsule-header"><span class="capsule-title">${n.title || "Attention"}</span><span class="capsule-time">${timeAgo}</span></div>
            <div class="capsule-message">${formattedMsg}</div>
          </div>
          <button class="capsule-close main-dismiss" data-id="${n.id}">&times;</button>
        </div>`;
            }
        });

        if (mainHtml) { bar.innerHTML = mainHtml; bar.style.display = "block"; }
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? "flex" : "none";
        }

        if (dropdownContent) {
            const header = document.querySelector(".notif-dropdown-header");
            if (header) {
                header.innerHTML = `<span>Notifications</span><div style="display:flex; align-items:center; gap:12px;">${unreadCount > 0 ? '<button id="clear-all-notifs" class="notif-clear-all">Clear All</button>' : ""}<button id="close-hub" class="modal-close" style="width:26px; height:26px; font-size:16px;">&times;</button></div>`;
            }
            dropdownContent.innerHTML = dropdownHtml || '<div class="notif-empty"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>No new notifications</div>';

            const clearBtn = document.getElementById("clear-all-notifs");
            if (clearBtn) {
                clearBtn.onclick = async () => {
                    const res = await chrome.storage.local.get(["dismissedNotifications"]);
                    const cur = res.dismissedNotifications || [];
                    // Fix: Only clear regular notifications, leave ads (imageUrl) alone
                    notifs.forEach(n => {
                        if (!n.imageUrl && !cur.includes(n.id)) cur.push(n.id);
                    });
                    await chrome.storage.local.set({ dismissedNotifications: cur });
                    fetchPersonalNotifications(email);
                };
            }
        }

        // Expand/Dismiss Listeners
        document.querySelectorAll('[data-expandable="true"]').forEach(el => {
            el.onclick = (e) => {
                if (e.target.closest("button") || e.target.closest("a")) return;
                el.classList.toggle("expanded");
                const sm = el.querySelector(".notif-see-more");
                if (sm) sm.textContent = el.classList.contains("expanded") ? "Show less" : "See more";
            };
        });

        document.querySelectorAll(".main-dismiss").forEach(btn => {
            btn.onclick = async (e) => {
                e.stopPropagation();
                const id = btn.getAttribute("data-id");
                document.getElementById("notif-main-" + id)?.remove();
                const s = await chrome.storage.local.get(["dismissedMainNotifications"]);
                const d = s.dismissedMainNotifications || [];
                if (!d.includes(id)) { d.push(id); chrome.storage.local.set({ dismissedMainNotifications: d }); }
            };
        });

        document.querySelectorAll(".drop-dismiss").forEach(btn => {
            btn.onclick = async (e) => {
                e.stopPropagation();
                const id = btn.getAttribute("data-id");
                document.getElementById("notif-drop-" + id).style.display = "none";
                document.getElementById("notif-main-" + id)?.remove();
                const s = await chrome.storage.local.get(["dismissedNotifications"]);
                const d = s.dismissedNotifications || [];
                if (!d.includes(id)) { d.push(id); chrome.storage.local.set({ dismissedNotifications: d }); }
                if (badge) {
                    let c = Math.max(0, parseInt(badge.textContent) - 1);
                    badge.textContent = c;
                    if (c === 0) badge.style.display = "none";
                }
            };
        });
        window._npLoadingNotifs = false;
    } catch (err) {
        window._npLoadingNotifs = false;
        console.warn("Newton+ notification error:", err);
    }
}