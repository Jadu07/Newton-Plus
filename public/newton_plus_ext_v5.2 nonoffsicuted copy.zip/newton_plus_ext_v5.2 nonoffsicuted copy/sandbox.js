// ── NEW: Internal Sandbox Scrollbar Hiding ───────────────────────────────────
function _applySandboxStyles() {
  const styleId = 'newton-plus-sandbox-styles';
  if (document.getElementById(styleId)) return;
  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    html, body {
      margin: 0 !important;
      padding: 0 !important;
      overflow: hidden !important;
      scrollbar-width: none !important;
      -ms-overflow-style: none !important;
    }
    *::-webkit-scrollbar, ::webkit-scrollbar {
      display: none !important;
      width: 0 !important;
      height: 0 !important;
    }
  `;
  (document.head || document.documentElement).appendChild(style);
}

window.addEventListener('message', async function (event) {
  const { command, content, script, context, code, _0x5a2b, _0x3d91, _0x1a2b, gistUrl } = event.data;

  // ── 1. Legacy/Direct Script Execution ─────────────────────────────────
  if (command === 'runext' || command === 'executeBlockScript') {
    const scriptToRun = code || script;
    if (!scriptToRun) return;
    try {
      // Must pass legacy obfuscated parameters explicitly to match what is extracted from event.data
      const fn = new Function('_0x539f35', '_0x78141b', '_0x48b277', 'gistUrl', 'ctx', scriptToRun);
      fn(_0x5a2b, _0x3d91, _0x1a2b, gistUrl, event.data);
    } catch (e) {
      console.error("Newton+ sandbox: execution error:", e);
    }
  }

  // ── 2. NEW: Full Interactive Block Rendering ──────────────────────────
  if (command === 'renderInteractiveBlock') {
    const blockId = context.blockId;
    const storageKey = `np_block_hidden_${blockId}`;

    // A. Safe localStorage wrapper — sandbox iframe lacks allow-same-origin so
    //    direct localStorage access throws a SecurityError. Silently skip if unavailable.
    const _safeGetStorage = (key) => {
      try { return localStorage.getItem(key); } catch (e) { return null; }
    };

    if (_safeGetStorage(storageKey)) {
      window.parent.postMessage({ type: 'hide-block', blockId: blockId }, "*");
      return;
    }


    try {
      _applySandboxStyles(); // Hide scrollbars inside the sandbox
      // B. Inject HTML Content
      document.body.innerHTML = content || "";

      // C. Execute Script (now in the same DOM context!)
      if (script) {
        const fn = new Function('ctx', script);
        fn(context || {});
      }

      // C. Start Resize Observer to report height back to parent
      reportHeight(context.blockId);
      setupResizeObserver(context.blockId);

    } catch (e) {
      console.error("Newton+ sandbox: interactive render error:", e);
    }
  }
});

// Helper to report content height to the parent popup
function reportHeight(blockId) {
  const height = (document.documentElement.scrollHeight || document.body.scrollHeight);
  window.parent.postMessage({
    type: 'resize-custom-block',
    blockId: blockId,
    height: height
  }, "*");
}

// Watch for DOM changes (like toggling a QR code) and notify the parent
function setupResizeObserver(blockId) {
  const observer = new MutationObserver(() => {
    reportHeight(blockId);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true
  });

  // Also interval check for cases where mutations might miss (like images loading)
  setInterval(() => reportHeight(blockId), 1000);
}